# Hidden Marker Experiment

This directory contains the self-contained GPU runner for Experiment 1. The
default invocation runs the specified 100-carrier calibration and all 64 paired
episodes (128 trials) with unquantized BF16 `Qwen/Qwen3-14B`.

```bash
GPU=auto gpurun experiment/run_experiment.py \
  --output-dir /data/agastyas/hidden-marker-lab/full
```

The runner writes:

- `experiment-results.json`: complete run metadata, calibration norms, episode
  vector summaries, token positions, logits, signed margins, and aggregate
  statistics.
- `experiment-results.checkpoint.json`: atomically refreshed after each episode
  and accepted by `--resume`.
- `intervention-vectors-fp32.npz`: every full `v1` and `v2` vector in FP32.

Use `--overwrite` only to replace an existing completed output. Use `--resume`
to continue a matching checkpoint. A minimal validation run is:

```bash
GPU=auto gpurun experiment/run_experiment.py \
  --episodes 2 --calibration 4 \
  --output-dir /data/agastyas/hidden-marker-lab/smoke \
  --overwrite
```

No API key is required for the public Qwen checkpoint. The Athena wrapper uses
the shared Hugging Face cache and configures cluster network access.

The binary dax variant uses the same interventions, carriers, and seeds while
scoring the single-token continuations `YES` and `NO`:

```bash
GPU=auto gpurun experiment/run_experiment.py \
  --experiment binary-dax \
  --output-dir /data/agastyas/hidden-marker-lab/binary-full
```

Its `before` logits are a separate matched pre-exposure prompt: the two
demonstrations and binary question are present, but the test carrier is withheld
and no test vector is injected. They estimate a response prior rather than an
intermediate state from the posterior forward pass.

## Fine-tuning for functional access

`train_introspection.py` is a self-contained BF16 training and evaluation
runner for Experiment 3. It adds custom rank-16 LoRA modules downstream of the
injection site while sampling fresh FP32 intervention directions online. The
curriculum has three phases: locating one intervention among four carriers,
judging whether two interventions match, and binding two interventions to
arbitrary nonce labels. Intervention strength is annealed from `rho=0.5–2.0`
to `rho=0.02–0.2`.

```bash
python experiment/train_introspection.py \
  --mode train \
  --output-dir /data/agastyas/hidden-marker-ift/seed-20260820 \
  --seed 20260820 \
  --steps 2500 \
  --localization-steps 200 \
  --same-different-steps 500 \
  --train-layers 20 \
  --validation-layer 20 \
  --lora-start-layer 20
```

Evaluation uses held-out labels, a disjoint subject/predicate content-phrase
pool, fresh random vectors, the full eight-element
mapping/demo-order/option-order counterfactual orbit, both test directions, and
controls for intervention strength, absent or altered test markers, vector
family, carrier identity, and injection layer:

```bash
python experiment/train_introspection.py \
  --mode eval \
  --output-dir /data/agastyas/hidden-marker-ift/seed-20260820 \
  --seed 909090 \
  --adapter /data/agastyas/hidden-marker-ift/seed-20260820/best-adapter.pt \
  --primary-episodes 256 \
  --secondary-episodes 128 \
  --eval-layers 16,20,24
```

`aggregate_introspection.py` combines the matched base-model and multi-seed
evaluations, computes a paired cluster-bootstrap interval, and emits separate
aggregate and complete-trial dashboard artifacts.

The completed run retained its adapter checkpoints under
`/data/agastyas/hidden-marker-ift/` on Athena. Their exact paths, byte sizes,
and SHA-256 hashes are recorded in
`experiment/results/introspection-training/adapter-manifest.json`.

Checkpoint selection used the training carrier vocabulary with a separate
validation seed. The final reported evaluation is stricter: it uses the
disjoint content-phrase pool defined by `EVAL_SUBJECTS` and `EVAL_PREDICATES`.
Thus the final carrier split did not influence adapter selection.

## OOD and mechanistic experiment

The preregistered Experiment 4 protocol is `experiment4_protocol.md`. The OOD
runner evaluates a frozen adapter over direction-family, correlation, prompt,
carrier, token-position, layer, span, angular-morph, and joint shifts:

```bash
python experiment/run_ood_introspection.py \
  --adapter /data/agastyas/hidden-marker-ift/full-seed-20260820/best-adapter.pt \
  --output-dir /data/agastyas/hidden-marker-ift/experiment4/ood-seed-20260820
```

For the strict span test, train only on `--direction-mode subspace-train` with a
fixed `--subspace-seed`, then evaluate the same checkpoint separately on
`subspace-train` and `subspace-holdout`. The two halves are a signed, permuted,
block-Walsh-Hadamard basis partition with maximum observed cross-half dot product
below `2e-9` in FP32.

`mechanistic_introspection.py` uses native Qwen3 hooks to screen attention,
measure Q/K/V/O LoRA head structure, perform position-specific mean or zero
ablation, patch counterfactual activations at the test marker, and compare head
groups with matched controls. The executed analysis is available in
`notebooks/introspection_head_analysis.ipynb` and its rendered HTML counterpart.

## Complete replication notebook

`notebooks/hidden_marker_lab_replication.ipynb` defines the core experimental
code directly, then runs both base-model experiments, online LoRA training,
matched evaluation, OOD tests, exactly orthogonal-span training, mechanistic
screening, causal ablation, activation patching, aggregation, and invariant
checks. Its default mode loads the committed results; setting
`RUN_GPU_EXPERIMENTS = True` and `RUN_MECHANISTIC_ANALYSIS = True` executes the
complete GPU workflow.

The notebook embeds the runner scripts, recorded summaries, and local-interface
source that it needs. A downloaded `.ipynb` can therefore run its default CPU
analysis from an otherwise empty directory. The opening setup cells verify and
extract that bundle. They install NumPy, Matplotlib, or PyTorch only when one of
those packages is missing. A full GPU reproduction still requires a suitable
CUDA-enabled PyTorch environment and the packages in
`requirements-replication.txt`.

## Local intervention interface

`local_gui/athena_app.py` is a self-contained GPU server for Residual Marker
Studio. It supports the original label and binary prompts as well as arbitrary
free-form text. The browser shows the exact prompt tokens and lets the user
paint either sampled residual direction onto any token positions. It can run
the base model, the three fixed-site LoRA replications, or the cross-layer LoRA
adapter, with matched base-versus-trained output and first-token logits.

`local_gui/launch.py` starts the server through `gpurun`, creates a private SSH
tunnel, and returns a `localhost` URL. The replication notebook includes a
gated launch cell near the top. In a downloaded notebook, run the two embedded
support cells before enabling that launch cell. The interface is local and is
not part of the deployed results dashboard.
