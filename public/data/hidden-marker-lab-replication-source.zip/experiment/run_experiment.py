#!/usr/bin/env python3
"""Run Experiment 1: in-context labeling of hidden-state interventions.

This file is intentionally self-contained because ``gpurun`` uploads one Python
file per job. It writes a checkpoint after every episode, a final JSON artifact
for the audit interface, and the complete FP32 intervention vectors as an NPZ.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import statistics
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer


MODEL_ID = "Qwen/Qwen3-14B"
DEFAULT_SEED = 20260811
RHO = 0.1

SYSTEM_PROMPT = (
    "During this conversation, two arbitrary hidden markers may occur while\n"
    "you read a sentence. Their names are arbitrary and are defined only by\n"
    "the examples. Answer the final question with only A or B."
)

BINARY_SYSTEM_PROMPT = (
    "During this conversation, an arbitrary hidden marker might be injected "
    "into your internal activations while you read a sentence. Its name is "
    "arbitrary and is defined only by the examples. Answer the final question "
    "with only YES or NO."
)

EPISODE_SENTENCES = [
    "The copper lantern stood beside the window.",
    "A linen map rested beneath the compass.",
    "The narrow footbridge crossed the quiet stream.",
    "A blue teacup waited near the kettle.",
    "The cedar chest remained under the staircase.",
    "A paper kite drifted above the meadow.",
    "The brass key lay beside the notebook.",
    "A small fern grew between the stones.",
    "The morning ferry approached the eastern pier.",
    "A wool scarf hung behind the door.",
    "The glass marble rolled across the table.",
    "A white heron watched from the riverbank.",
    "The old clock chimed before the rain.",
    "A wooden spoon rested inside the bowl.",
    "The garden gate opened toward the orchard.",
    "A silver thimble gleamed on the shelf.",
    "The empty canoe floated beside the reeds.",
    "A folded letter waited under the book.",
    "The distant lighthouse marked the rocky coast.",
    "A green bottle stood near the basin.",
    "The striped blanket covered the wooden bench.",
    "A clay whistle sat beside the candle.",
    "The evening train passed beyond the hill.",
    "A red ribbon circled the parcel.",
    "The stone fountain stood within the courtyard.",
    "A yellow leaf landed on the railing.",
    "The canvas satchel leaned against the chair.",
    "A quiet sparrow perched above the doorway.",
    "The iron bell hung inside the tower.",
    "A shallow basket held three apples.",
    "The moonlit path curved around the pond.",
    "A ceramic vase rested on the mantel.",
    "The faded curtain moved in the breeze.",
    "A round pebble rested in the palm.",
    "The wooden ladder reached the lower roof.",
    "A cotton glove lay near the toolbox.",
    "The painted sign pointed toward the harbor.",
    "A black umbrella dried beside the radiator.",
    "The marble step felt cool after sunset.",
    "A woven mat covered the entryway.",
    "The tin cup balanced on the fencepost.",
    "A pale shell rested among the sand.",
    "The orchard path ended at the stone wall.",
    "A leather journal remained inside the drawer.",
    "The little windmill turned above the barn.",
    "A crystal bead caught the afternoon light.",
    "The weathered rope coiled beside the anchor.",
    "A dry twig snapped beneath the boot.",
    "The quiet library overlooked the square.",
    "A bronze coin rested under the cushion.",
    "The narrow chimney rose above the tiles.",
    "A striped shell lay near the tide line.",
    "The willow branch touched the still water.",
    "A square envelope stood against the lamp.",
    "The mossy steps descended toward the spring.",
    "A tiny feather clung to the sleeve.",
    "The bakery window faced the market street.",
    "A porcelain button rolled beneath the cabinet.",
    "The distant wind carried the sound of bells.",
    "A clean towel rested beside the basin.",
    "The oak drawer held a spool of thread.",
    "A grey rabbit paused near the hedgerow.",
    "The narrow bookshelf stood beside the fireplace.",
    "A copper pan hung above the counter.",
]


def make_calibration_sentences() -> list[str]:
    """Create a deterministic set of 100 plain, declarative carriers."""
    subjects = [
        "amber candle", "birch box", "canvas pouch", "ceramic plate",
        "cotton apron", "glass pitcher", "iron latch", "linen cloth",
        "paper parcel", "silver spoon",
    ]
    locations = [
        "beside the window", "beneath the shelf", "near the doorway",
        "inside the cabinet", "behind the curtain", "above the hearth",
        "under the table", "against the wall", "by the staircase",
        "next to the basket",
    ]
    return [f"The {subject} rested {location}." for subject in subjects for location in locations]


CALIBRATION_SENTENCES = make_calibration_sentences()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=path.parent, delete=False, suffix=".tmp"
    ) as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
        tmp_path = Path(handle.name)
    os.replace(tmp_path, path)


def quantile(values: Sequence[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("quantile requires at least one value")
    pos = (len(ordered) - 1) * q
    lower = math.floor(pos)
    upper = math.ceil(pos)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] * (upper - pos) + ordered[upper] * (pos - lower)


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total <= 0:
        return 0.0, 1.0
    p = successes / total
    denom = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / denom
    radius = z * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total * total)) / denom
    return max(0.0, center - radius), min(1.0, center + radius)


def build_episode_messages(sentence: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": f"Example 1. Read the following sentence carefully:\n{sentence}",
        },
        {
            "role": "assistant",
            "content": "The hidden marker in that sentence was dax.",
        },
        {
            "role": "user",
            "content": f"Example 2. Read the following sentence carefully:\n{sentence}",
        },
        {
            "role": "assistant",
            "content": "The hidden marker in that sentence was wug.",
        },
        {
            "role": "user",
            "content": (
                f"Test. Read the following sentence carefully:\n{sentence}\n\n"
                "Which hidden marker occurred?\nA) dax\nB) wug"
            ),
        },
    ]


def render_episode_prompt(tokenizer: Any, sentence: str) -> str:
    rendered = tokenizer.apply_chat_template(
        build_episode_messages(sentence),
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    return rendered + "The answer is:"


def build_binary_demonstrations(sentence: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": BINARY_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Example 1. Read the following sentence carefully:\n{sentence}\n\n"
                "Did the dax hidden marker occur in that sentence?"
            ),
        },
        {"role": "assistant", "content": "YES"},
        {
            "role": "user",
            "content": (
                f"Example 2. Read the following sentence carefully:\n{sentence}\n\n"
                "Did the dax hidden marker occur in that sentence?"
            ),
        },
        {"role": "assistant", "content": "NO"},
    ]


def render_binary_before_prompt(tokenizer: Any, sentence: str) -> str:
    """Render the matched pre-exposure prior probe with no test carrier."""
    messages = build_binary_demonstrations(sentence) + [
        {
            "role": "user",
            "content": (
                "Test. The test sentence is withheld for this pre-exposure probe.\n\n"
                "Did the dax hidden marker occur in the test sentence?"
            ),
        }
    ]
    rendered = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    return rendered + "The answer is:"


def render_binary_after_prompt(tokenizer: Any, sentence: str) -> str:
    messages = build_binary_demonstrations(sentence) + [
        {
            "role": "user",
            "content": (
                f"Test. Read the following sentence carefully:\n{sentence}\n\n"
                "Did the dax hidden marker occur in the test sentence?"
            ),
        }
    ]
    rendered = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    return rendered + "The answer is:"


def render_calibration_prompt(
    tokenizer: Any, sentence: str, system_prompt: str = SYSTEM_PROMPT
) -> str:
    messages = [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": f"Read the following sentence carefully:\n{sentence}",
        },
    ]
    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=False,
        enable_thinking=False,
    )


def occurrence_starts(text: str, needle: str) -> list[int]:
    starts: list[int] = []
    cursor = 0
    while True:
        index = text.find(needle, cursor)
        if index < 0:
            return starts
        starts.append(index)
        cursor = index + len(needle)


def final_period_token_positions(
    tokenizer: Any, prompt: str, sentence: str, expected_occurrences: int
) -> tuple[list[int], list[int], list[str]]:
    if not sentence.endswith("."):
        raise ValueError(f"carrier sentence must end in a period: {sentence!r}")
    starts = occurrence_starts(prompt, sentence)
    if len(starts) != expected_occurrences:
        raise RuntimeError(
            f"expected {expected_occurrences} carrier occurrences, found {len(starts)}"
        )
    encoded = tokenizer(
        prompt,
        add_special_tokens=False,
        return_offsets_mapping=True,
    )
    offsets = encoded["offset_mapping"]
    token_ids = encoded["input_ids"]
    positions: list[int] = []
    pieces: list[str] = []
    period_indices = [start + len(sentence) - 1 for start in starts]
    for character_index in period_indices:
        matches = [
            index
            for index, (begin, end) in enumerate(offsets)
            if begin <= character_index < end
        ]
        if len(matches) != 1:
            raise RuntimeError(
                f"period at character {character_index} mapped to token positions {matches}"
            )
        position = matches[0]
        positions.append(position)
        pieces.append(tokenizer.decode([token_ids[position]], clean_up_tokenization_spaces=False))
    return positions, [int(token_ids[position]) for position in positions], pieces


def choose_candidate_tokens(tokenizer: Any, requested: str) -> dict[str, Any]:
    choices: list[tuple[str, str]]
    if requested == "space":
        choices = [("leading-space", " ")]
    elif requested == "bare":
        choices = [("bare", "")]
    else:
        choices = [("leading-space", " "), ("bare", "")]

    failures: list[str] = []
    for name, prefix in choices:
        ids_a = tokenizer.encode(prefix + "A", add_special_tokens=False)
        ids_b = tokenizer.encode(prefix + "B", add_special_tokens=False)
        if len(ids_a) == 1 and len(ids_b) == 1 and ids_a[0] != ids_b[0]:
            return {
                "format": name,
                "A": {
                    "id": int(ids_a[0]),
                    "requested_text": prefix + "A",
                    "decoded_piece": tokenizer.decode(ids_a, clean_up_tokenization_spaces=False),
                },
                "B": {
                    "id": int(ids_b[0]),
                    "requested_text": prefix + "B",
                    "decoded_piece": tokenizer.decode(ids_b, clean_up_tokenization_spaces=False),
                },
                "verified_single_token": True,
            }
        failures.append(
            f"{name}: A={ids_a!r}, B={ids_b!r}"
        )
    raise RuntimeError("A/B are not distinct single-token continuations; " + "; ".join(failures))


def choose_binary_candidate_tokens(tokenizer: Any, requested: str) -> dict[str, Any]:
    choices: list[tuple[str, str]]
    if requested == "space":
        choices = [("leading-space", " ")]
    elif requested == "bare":
        choices = [("bare", "")]
    else:
        choices = [("leading-space", " "), ("bare", "")]

    failures: list[str] = []
    for name, prefix in choices:
        ids_yes = tokenizer.encode(prefix + "YES", add_special_tokens=False)
        ids_no = tokenizer.encode(prefix + "NO", add_special_tokens=False)
        if len(ids_yes) == 1 and len(ids_no) == 1 and ids_yes[0] != ids_no[0]:
            return {
                "format": name,
                "YES": {
                    "id": int(ids_yes[0]),
                    "requested_text": prefix + "YES",
                    "decoded_piece": tokenizer.decode(ids_yes, clean_up_tokenization_spaces=False),
                },
                "NO": {
                    "id": int(ids_no[0]),
                    "requested_text": prefix + "NO",
                    "decoded_piece": tokenizer.decode(ids_no, clean_up_tokenization_spaces=False),
                },
                "verified_single_token": True,
            }
        failures.append(f"{name}: YES={ids_yes!r}, NO={ids_no!r}")
    raise RuntimeError(
        "YES/NO are not distinct single-token continuations; " + "; ".join(failures)
    )


def get_transformer_layers(model: Any) -> Sequence[torch.nn.Module]:
    candidates = [
        getattr(getattr(model, "model", None), "layers", None),
        getattr(getattr(model, "base_model", None), "layers", None),
    ]
    for layers in candidates:
        if layers is not None:
            return layers
    raise RuntimeError("could not locate transformer block list on the loaded model")


@dataclass
class SiteController:
    """One pre-hook that either captures resid_pre norms or adds interventions."""

    capture_positions: list[list[int]] | None = None
    plan: list[dict[int, torch.Tensor]] | None = None
    captured_norms: list[float] | None = None

    def hook(
        self,
        _module: torch.nn.Module,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> tuple[tuple[Any, ...], dict[str, Any]]:
        if "hidden_states" in kwargs:
            hidden = kwargs["hidden_states"]
            hidden_in_kwargs = True
        elif args:
            hidden = args[0]
            hidden_in_kwargs = False
        else:
            raise RuntimeError("target block received no residual input")

        if self.capture_positions is not None:
            if len(self.capture_positions) != hidden.shape[0]:
                raise RuntimeError("capture batch does not match residual batch")
            norms = self.captured_norms if self.captured_norms is not None else []
            for batch_index, positions in enumerate(self.capture_positions):
                for position in positions:
                    norms.append(float(hidden[batch_index, position].float().norm().item()))
            self.captured_norms = norms

        if self.plan is None:
            return args, kwargs
        if len(self.plan) != hidden.shape[0]:
            raise RuntimeError("intervention plan does not match residual batch")

        modified = hidden.clone()
        for batch_index, row_plan in enumerate(self.plan):
            for position, delta in row_plan.items():
                modified[batch_index, position] = modified[batch_index, position] + delta

        if hidden_in_kwargs:
            new_kwargs = dict(kwargs)
            new_kwargs["hidden_states"] = modified
            return args, new_kwargs
        return (modified, *args[1:]), kwargs


def batches(items: Sequence[Any], size: int) -> Iterable[Sequence[Any]]:
    for start in range(0, len(items), size):
        yield items[start : start + size]


def vector_summary(vector: torch.Tensor) -> dict[str, Any]:
    vector = vector.detach().cpu().float().contiguous()
    raw = vector.numpy().tobytes(order="C")
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "norm": float(vector.norm().item()),
        "mean": float(vector.mean().item()),
        "std": float(vector.std(unbiased=False).item()),
        "min": float(vector.min().item()),
        "max": float(vector.max().item()),
        "first_12_coordinates": [float(value) for value in vector[:12].tolist()],
    }


def sample_pair(hidden_size: int, seed: int) -> tuple[torch.Tensor, torch.Tensor]:
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    gaussian = torch.randn(hidden_size, 2, dtype=torch.float32, generator=generator)
    q, r = torch.linalg.qr(gaussian, mode="reduced")
    signs = torch.sign(torch.diag(r))
    signs[signs == 0] = 1
    q = q * signs.unsqueeze(0)
    return q[:, 0].contiguous(), q[:, 1].contiguous()


def aggregate_trials(episodes: Sequence[dict[str, Any]]) -> dict[str, Any]:
    trials = [trial for episode in episodes for trial in episode["trials"]]
    margins = [float(trial["margin"]) for trial in trials]
    correct = sum(bool(trial["correct"]) for trial in trials)
    ci_low, ci_high = wilson_interval(correct, len(trials))

    by_vector: dict[str, Any] = {}
    for vector_name in ("v1", "v2"):
        subset = [trial for trial in trials if trial["test_vector"] == vector_name]
        subset_margins = [float(trial["margin"]) for trial in subset]
        subset_correct = sum(bool(trial["correct"]) for trial in subset)
        lo, hi = wilson_interval(subset_correct, len(subset))
        by_vector[vector_name] = {
            "n_trials": len(subset),
            "n_correct": subset_correct,
            "accuracy": subset_correct / len(subset) if subset else 0.0,
            "ci_95_wilson": [lo, hi],
            "mean_margin": statistics.fmean(subset_margins) if subset_margins else 0.0,
        }

    return {
        "n_trials": len(trials),
        "n_correct": correct,
        "accuracy": correct / len(trials) if trials else 0.0,
        "chance_accuracy": 0.5,
        "ci_95": {
            "method": "Wilson score interval",
            "level": 0.95,
            "low": ci_low,
            "high": ci_high,
        },
        "mean_margin": statistics.fmean(margins) if margins else 0.0,
        "median_margin": statistics.median(margins) if margins else 0.0,
        "margin_std": statistics.pstdev(margins) if len(margins) > 1 else 0.0,
        "margin_min": min(margins) if margins else 0.0,
        "margin_max": max(margins) if margins else 0.0,
        "margin_quartiles": [
            quantile(margins, 0.25) if margins else 0.0,
            quantile(margins, 0.5) if margins else 0.0,
            quantile(margins, 0.75) if margins else 0.0,
        ],
        "by_test_vector": by_vector,
    }


def summarize_binary_stage(trials: Sequence[dict[str, Any]], stage: str) -> dict[str, Any]:
    correct_key = f"{stage}_correct"
    margin_key = f"{stage}_margin"
    prediction_key = f"{stage}_prediction"
    margins = [float(trial[margin_key]) for trial in trials]
    correct = sum(bool(trial[correct_key]) for trial in trials)
    ci_low, ci_high = wilson_interval(correct, len(trials))
    return {
        "n_trials": len(trials),
        "n_correct": correct,
        "accuracy": correct / len(trials) if trials else 0.0,
        "ci_95": {
            "method": "Wilson score interval",
            "level": 0.95,
            "low": ci_low,
            "high": ci_high,
        },
        "mean_margin": statistics.fmean(margins) if margins else 0.0,
        "median_margin": statistics.median(margins) if margins else 0.0,
        "margin_std": statistics.pstdev(margins) if len(margins) > 1 else 0.0,
        "margin_min": min(margins) if margins else 0.0,
        "margin_max": max(margins) if margins else 0.0,
        "prediction_counts": {
            "YES": sum(trial[prediction_key] == "YES" for trial in trials),
            "NO": sum(trial[prediction_key] == "NO" for trial in trials),
        },
    }


def aggregate_binary_trials(episodes: Sequence[dict[str, Any]]) -> dict[str, Any]:
    trials = [trial for episode in episodes for trial in episode["trials"]]
    after = summarize_binary_stage(trials, "after")
    before = summarize_binary_stage(trials, "before")
    evidence_shifts = [float(trial["correct_evidence_shift"]) for trial in trials]
    raw_shifts = [float(trial["delta_raw_yes_minus_no"]) for trial in trials]

    by_vector: dict[str, Any] = {}
    for vector_name in ("v1", "v2"):
        subset = [trial for trial in trials if trial["test_vector"] == vector_name]
        stage = summarize_binary_stage(subset, "after")
        stage["before"] = summarize_binary_stage(subset, "before")
        stage["mean_correct_evidence_shift"] = statistics.fmean(
            float(trial["correct_evidence_shift"]) for trial in subset
        ) if subset else 0.0
        stage["mean_raw_yes_minus_no_shift"] = statistics.fmean(
            float(trial["delta_raw_yes_minus_no"]) for trial in subset
        ) if subset else 0.0
        by_vector[vector_name] = stage

    return {
        "n_trials": len(trials),
        "chance_accuracy": 0.5,
        "before": before,
        "after": after,
        "mean_correct_evidence_shift": statistics.fmean(evidence_shifts) if evidence_shifts else 0.0,
        "median_correct_evidence_shift": statistics.median(evidence_shifts) if evidence_shifts else 0.0,
        "mean_raw_yes_minus_no_shift": statistics.fmean(raw_shifts) if raw_shifts else 0.0,
        "prediction_switches": sum(
            trial["before_prediction"] != trial["after_prediction"] for trial in trials
        ),
        "by_test_vector": by_vector,
    }


def base_result(
    args: argparse.Namespace,
    model: Any,
    layer_index: int,
    candidate_tokens: dict[str, Any],
    calibration: dict[str, Any],
    alpha: float,
    prompt_example: str,
    started_at_utc: str,
) -> dict[str, Any]:
    config = model.config
    return {
        "schema_version": 1,
        "status": "running",
        "run": {
            "id": f"qwen3-14b-hidden-marker-seed-{args.seed}",
            "started_at_utc": started_at_utc,
            "completed_at_utc": None,
            "duration_seconds": None,
            "seed": args.seed,
            "host": platform.node(),
            "python_version": platform.python_version(),
            "torch_version": torch.__version__,
            "transformers_version": transformers.__version__,
            "cuda_version": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(0),
            "model_id": args.model_id,
            "model_revision": getattr(config, "_commit_hash", None),
            "model_dtype": str(next(model.parameters()).dtype).replace("torch.", ""),
            "evaluation_mode": not model.training,
            "sampling": False,
        },
        "design": {
            "title": "In-context labeling of hidden-state interventions",
            "episodes_planned": args.episodes,
            "trials_planned": args.episodes * 2,
            "rho": RHO,
            "alpha": alpha,
            "layer_index_zero_based": layer_index,
            "layer_ordinal_one_based": layer_index + 1,
            "num_layers": int(config.num_hidden_layers),
            "site": "resid_pre",
            "target": "final period token of each carrier occurrence",
            "hidden_size": int(config.hidden_size),
            "vector_distribution": "orthonormalized iid Gaussian pair via FP32 QR",
            "vector_storage_dtype": "float32",
            "injection_dtype": str(next(model.parameters()).dtype).replace("torch.", ""),
            "demonstration_mapping": {"v1": "dax", "v2": "wug"},
            "option_mapping": {"A": "dax", "B": "wug"},
            "option_order_fixed": True,
            "complete_prompt_single_causal_forward": True,
            "paired_trials_batched_together": True,
            "chat_template": "official tokenizer chat template with enable_thinking=False",
        },
        "tokenization": candidate_tokens,
        "calibration": calibration,
        "prompt_example_rendered": prompt_example,
        "aggregate": None,
        "episodes": [],
    }


def base_binary_result(
    args: argparse.Namespace,
    model: Any,
    layer_index: int,
    candidate_tokens: dict[str, Any],
    calibration: dict[str, Any],
    alpha: float,
    before_prompt_example: str,
    after_prompt_example: str,
    started_at_utc: str,
) -> dict[str, Any]:
    config = model.config
    return {
        "schema_version": 1,
        "status": "running",
        "run": {
            "id": f"qwen3-14b-binary-dax-seed-{args.seed}",
            "started_at_utc": started_at_utc,
            "completed_at_utc": None,
            "duration_seconds": None,
            "seed": args.seed,
            "host": platform.node(),
            "python_version": platform.python_version(),
            "torch_version": torch.__version__,
            "transformers_version": transformers.__version__,
            "cuda_version": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(0),
            "model_id": args.model_id,
            "model_revision": getattr(config, "_commit_hash", None),
            "model_dtype": str(next(model.parameters()).dtype).replace("torch.", ""),
            "evaluation_mode": not model.training,
            "sampling": False,
        },
        "design": {
            "title": "Binary dax detection with pre/post exposure probes",
            "experiment": "binary-dax",
            "episodes_planned": args.episodes,
            "trials_planned": args.episodes * 2,
            "rho": RHO,
            "alpha": alpha,
            "layer_index_zero_based": layer_index,
            "layer_ordinal_one_based": layer_index + 1,
            "num_layers": int(config.num_hidden_layers),
            "site": "resid_pre",
            "target": "final period token of each visible carrier occurrence",
            "hidden_size": int(config.hidden_size),
            "vector_distribution": "orthonormalized iid Gaussian pair via FP32 QR",
            "vector_storage_dtype": "float32",
            "injection_dtype": str(next(model.parameters()).dtype).replace("torch.", ""),
            "demonstration_mapping": {"v1": "YES / dax", "v2": "NO / not-dax"},
            "answer_mapping": {"YES": "dax occurred", "NO": "dax did not occur"},
            "answer_order_fixed": True,
            "after_complete_prompt_single_causal_forward": True,
            "after_paired_trials_batched_together": True,
            "before_probe": {
                "definition": (
                    "Matched pre-exposure prior: demonstrations and the binary question are "
                    "present, but the test carrier is withheld and no test vector is injected."
                ),
                "caveat": (
                    "The before probe is a separate complete prompt and estimates a response "
                    "prior; it is not an intermediate causal state from the after forward pass."
                ),
                "one_forward_per_episode": True,
                "shared_across_paired_v1_v2_trials": True,
            },
            "chat_template": "official tokenizer chat template with enable_thinking=False",
        },
        "system_prompt": BINARY_SYSTEM_PROMPT,
        "tokenization": candidate_tokens,
        "calibration": calibration,
        "prompt_examples_rendered": {
            "before": before_prompt_example,
            "after": after_prompt_example,
        },
        "aggregate": None,
        "episodes": [],
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-id", default=MODEL_ID)
    parser.add_argument(
        "--experiment",
        choices=("label-choice", "binary-dax"),
        default="label-choice",
    )
    parser.add_argument("--episodes", type=int, default=64)
    parser.add_argument("--calibration", type=int, default=100)
    parser.add_argument("--calibration-batch-size", type=int, default=8)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--candidate-format", choices=("auto", "space", "bare"), default="auto")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 1 <= args.episodes <= len(EPISODE_SENTENCES):
        raise ValueError(f"--episodes must be between 1 and {len(EPISODE_SENTENCES)}")
    if not 1 <= args.calibration <= len(CALIBRATION_SENTENCES):
        raise ValueError(f"--calibration must be between 1 and {len(CALIBRATION_SENTENCES)}")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required; run this script through gpurun")
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError("the selected GPU does not report BF16 support")

    output_dir = args.output_dir.expanduser().resolve()
    checkpoint_path = output_dir / "experiment-results.checkpoint.json"
    final_path = output_dir / "experiment-results.json"
    vectors_path = output_dir / "intervention-vectors-fp32.npz"
    output_dir.mkdir(parents=True, exist_ok=True)
    if final_path.exists() and not args.overwrite and not args.resume:
        raise FileExistsError(
            f"{final_path} already exists; use --resume or --overwrite explicitly"
        )

    started = time.time()
    started_at_utc = utc_now()
    print(f"[{utc_now()}] loading tokenizer {args.model_id}", flush=True)
    tokenizer = AutoTokenizer.from_pretrained(args.model_id, use_fast=True)
    tokenizer.padding_side = "right"
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    print(f"[{utc_now()}] loading unquantized BF16 model", flush=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_id,
        torch_dtype=torch.bfloat16,
        device_map={"": 0},
        low_cpu_mem_usage=True,
        attn_implementation="sdpa",
    )
    model.eval()
    torch.set_grad_enabled(False)
    if model.training:
        raise RuntimeError("model did not enter evaluation mode")
    parameter_dtype = next(model.parameters()).dtype
    if parameter_dtype != torch.bfloat16:
        raise RuntimeError(f"expected BF16 model parameters, got {parameter_dtype}")
    if getattr(model, "is_quantized", False):
        raise RuntimeError("loaded model unexpectedly reports quantization")

    layers = get_transformer_layers(model)
    num_layers = len(layers)
    layer_index = num_layers // 2
    if num_layers != int(model.config.num_hidden_layers):
        raise RuntimeError("model layer list disagrees with config.num_hidden_layers")
    controller = SiteController()
    hook_handle = layers[layer_index].register_forward_pre_hook(controller.hook, with_kwargs=True)

    try:
        is_binary = args.experiment == "binary-dax"
        candidate_tokens = (
            choose_binary_candidate_tokens(tokenizer, args.candidate_format)
            if is_binary
            else choose_candidate_tokens(tokenizer, args.candidate_format)
        )
        prompt_example = (
            render_binary_after_prompt(tokenizer, EPISODE_SENTENCES[0])
            if is_binary
            else render_episode_prompt(tokenizer, EPISODE_SENTENCES[0])
        )
        example_positions, example_token_ids, example_pieces = final_period_token_positions(
            tokenizer, prompt_example, EPISODE_SENTENCES[0], expected_occurrences=3
        )
        prefix_ids = tokenizer(prompt_example, add_special_tokens=False)["input_ids"]
        if example_positions[-1] >= len(prefix_ids) - 1:
            raise RuntimeError("test injection site overlaps the answer prefix boundary")
        print(
            f"[{utc_now()}] layer={layer_index}/{num_layers - 1} "
            f"period_positions={example_positions} candidates="
            + (
                f"YES:{candidate_tokens['YES']['id']} NO:{candidate_tokens['NO']['id']}"
                if is_binary
                else f"A:{candidate_tokens['A']['id']} B:{candidate_tokens['B']['id']}"
            ),
            flush=True,
        )

        calibration_sentences = CALIBRATION_SENTENCES[: args.calibration]
        calibration_norms: list[float] = []
        print(f"[{utc_now()}] calibrating on {len(calibration_sentences)} carriers", flush=True)
        for batch_sentences in batches(calibration_sentences, args.calibration_batch_size):
            prompts = [
                render_calibration_prompt(
                    tokenizer,
                    sentence,
                    BINARY_SYSTEM_PROMPT if is_binary else SYSTEM_PROMPT,
                )
                for sentence in batch_sentences
            ]
            positions = [
                final_period_token_positions(tokenizer, prompt, sentence, 1)[0]
                for prompt, sentence in zip(prompts, batch_sentences)
            ]
            model_inputs = tokenizer(
                prompts,
                add_special_tokens=False,
                padding=True,
                return_tensors="pt",
            ).to(model.device)
            controller.capture_positions = positions
            controller.captured_norms = []
            controller.plan = None
            _ = model(**model_inputs, use_cache=False, return_dict=True)
            calibration_norms.extend(controller.captured_norms or [])
            controller.capture_positions = None
            controller.captured_norms = None

        if len(calibration_norms) != len(calibration_sentences):
            raise RuntimeError("calibration did not capture exactly one norm per sentence")
        residual_norm = statistics.median(calibration_norms)
        alpha = RHO * residual_norm
        calibration = {
            "count": len(calibration_norms),
            "format": "system instruction plus one ordinary user carrier, official chat template",
            "median_residual_norm": residual_norm,
            "rho": RHO,
            "alpha": alpha,
            "min": min(calibration_norms),
            "q1": quantile(calibration_norms, 0.25),
            "q3": quantile(calibration_norms, 0.75),
            "max": max(calibration_norms),
            "norms": calibration_norms,
            "sentences": calibration_sentences,
        }
        print(f"[{utc_now()}] R_l={residual_norm:.6f} alpha={alpha:.6f}", flush=True)

        result = (
            base_binary_result(
                args,
                model,
                layer_index,
                candidate_tokens,
                calibration,
                alpha,
                render_binary_before_prompt(tokenizer, EPISODE_SENTENCES[0]),
                prompt_example,
                started_at_utc,
            )
            if is_binary
            else base_result(
                args,
                model,
                layer_index,
                candidate_tokens,
                calibration,
                alpha,
                prompt_example,
                started_at_utc,
            )
        )
        result["tokenization"]["example_carrier_sites"] = {
            "positions": example_positions,
            "token_ids": example_token_ids,
            "decoded_pieces": example_pieces,
        }

        completed_episode_ids: set[int] = set()
        if args.resume and checkpoint_path.exists():
            prior = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            if prior.get("run", {}).get("seed") != args.seed:
                raise RuntimeError("checkpoint seed does not match --seed")
            if prior.get("design", {}).get("episodes_planned") != args.episodes:
                raise RuntimeError("checkpoint episode count does not match --episodes")
            prior_experiment = prior.get("design", {}).get("experiment", "label-choice")
            if prior_experiment != args.experiment:
                raise RuntimeError("checkpoint experiment does not match --experiment")
            result["episodes"] = prior.get("episodes", [])
            completed_episode_ids = {int(item["episode_id"]) for item in result["episodes"]}
            print(f"[{utc_now()}] resumed {len(completed_episode_ids)} completed episodes", flush=True)

        all_vectors: dict[str, np.ndarray] = {}
        for episode_index, sentence in enumerate(EPISODE_SENTENCES[: args.episodes]):
            episode_id = episode_index + 1
            vector_seed = args.seed + episode_index
            v1, v2 = sample_pair(int(model.config.hidden_size), vector_seed)
            all_vectors[f"episode_{episode_id:03d}_v1"] = v1.numpy()
            all_vectors[f"episode_{episode_id:03d}_v2"] = v2.numpy()
            if episode_id in completed_episode_ids:
                continue

            if is_binary:
                before_prompt = render_binary_before_prompt(tokenizer, sentence)
                before_positions, before_token_ids, before_pieces = final_period_token_positions(
                    tokenizer, before_prompt, sentence, expected_occurrences=2
                )
                before_encoded = tokenizer(
                    [before_prompt],
                    add_special_tokens=False,
                    padding=True,
                    return_tensors="pt",
                ).to(model.device)

                v1_device = (v1 * alpha).to(device=model.device, dtype=parameter_dtype)
                v2_device = (v2 * alpha).to(device=model.device, dtype=parameter_dtype)
                controller.capture_positions = None
                controller.plan = [{before_positions[0]: v1_device, before_positions[1]: v2_device}]
                before_outputs = model(**before_encoded, use_cache=False, return_dict=True)
                controller.plan = None
                binary_candidate_ids = [
                    candidate_tokens["YES"]["id"],
                    candidate_tokens["NO"]["id"],
                ]
                before_scores = (
                    before_outputs.logits[0, -1, binary_candidate_ids].float().detach().cpu()
                )
                before_yes = float(before_scores[0].item())
                before_no = float(before_scores[1].item())
                before_prediction = "YES" if before_yes > before_no else "NO"

                after_prompt = render_binary_after_prompt(tokenizer, sentence)
                after_positions, after_token_ids, after_pieces = final_period_token_positions(
                    tokenizer, after_prompt, sentence, expected_occurrences=3
                )
                after_encoded = tokenizer(
                    [after_prompt, after_prompt],
                    add_special_tokens=False,
                    padding=True,
                    return_tensors="pt",
                ).to(model.device)
                demo_1, demo_2, test_site = after_positions
                controller.plan = [
                    {demo_1: v1_device, demo_2: v2_device, test_site: v1_device},
                    {demo_1: v1_device, demo_2: v2_device, test_site: v2_device},
                ]
                after_outputs = model(**after_encoded, use_cache=False, return_dict=True)
                controller.plan = None
                after_scores = (
                    after_outputs.logits[:, -1, binary_candidate_ids].float().detach().cpu()
                )

                trial_rows: list[dict[str, Any]] = []
                for row, (test_vector, correct_answer, marker_status) in enumerate(
                    (("v1", "YES", "dax"), ("v2", "NO", "not-dax"))
                ):
                    after_yes = float(after_scores[row, 0].item())
                    after_no = float(after_scores[row, 1].item())
                    after_prediction = "YES" if after_yes > after_no else "NO"
                    before_margin = (
                        before_yes - before_no if correct_answer == "YES" else before_no - before_yes
                    )
                    after_margin = (
                        after_yes - after_no if correct_answer == "YES" else after_no - after_yes
                    )
                    before_raw = before_yes - before_no
                    after_raw = after_yes - after_no
                    trial_rows.append(
                        {
                            "trial_id": f"E{episode_id:02d}-{test_vector.upper()}",
                            "episode_id": episode_id,
                            "sentence": sentence,
                            "test_vector": test_vector,
                            "marker_status": marker_status,
                            "correct_answer": correct_answer,
                            "before_logit_YES": before_yes,
                            "before_logit_NO": before_no,
                            "before_raw_YES_minus_NO": before_raw,
                            "before_prediction": before_prediction,
                            "before_margin": before_margin,
                            "before_correct": before_prediction == correct_answer,
                            "after_logit_YES": after_yes,
                            "after_logit_NO": after_no,
                            "after_raw_YES_minus_NO": after_raw,
                            "after_prediction": after_prediction,
                            "after_margin": after_margin,
                            "after_correct": after_prediction == correct_answer,
                            "delta_logit_YES": after_yes - before_yes,
                            "delta_logit_NO": after_no - before_no,
                            "delta_raw_yes_minus_no": after_raw - before_raw,
                            "correct_evidence_shift": after_margin - before_margin,
                            "prediction_switched": before_prediction != after_prediction,
                            "before_answer_prefix_last_token_id": int(
                                before_encoded["input_ids"][0, -1].item()
                            ),
                            "after_answer_prefix_last_token_id": int(
                                after_encoded["input_ids"][row, -1].item()
                            ),
                        }
                    )

                episode = {
                    "episode_id": episode_id,
                    "sentence": sentence,
                    "vector_seed": vector_seed,
                    "vector_pair": {
                        "v1": vector_summary(v1),
                        "v2": vector_summary(v2),
                        "dot_product": float(torch.dot(v1, v2).item()),
                        "cosine_similarity": float(
                            torch.dot(v1, v2).item() / (v1.norm().item() * v2.norm().item())
                        ),
                    },
                    "injection_sites": {
                        "before": [
                            {
                                "role": "demonstration_1",
                                "position": before_positions[0],
                                "token_id": before_token_ids[0],
                                "decoded_piece": before_pieces[0],
                                "vector": "v1",
                                "binary_answer": "YES",
                            },
                            {
                                "role": "demonstration_2",
                                "position": before_positions[1],
                                "token_id": before_token_ids[1],
                                "decoded_piece": before_pieces[1],
                                "vector": "v2",
                                "binary_answer": "NO",
                            },
                        ],
                        "after": [
                            {
                                "role": "demonstration_1",
                                "position": demo_1,
                                "token_id": after_token_ids[0],
                                "decoded_piece": after_pieces[0],
                                "vector": "v1",
                                "binary_answer": "YES",
                            },
                            {
                                "role": "demonstration_2",
                                "position": demo_2,
                                "token_id": after_token_ids[1],
                                "decoded_piece": after_pieces[1],
                                "vector": "v2",
                                "binary_answer": "NO",
                            },
                            {
                                "role": "test",
                                "position": test_site,
                                "token_id": after_token_ids[2],
                                "decoded_piece": after_pieces[2],
                                "vector": "varies by paired trial",
                                "binary_answer": "unknown to model",
                            },
                        ],
                    },
                    "prompt_token_counts": {
                        "before": int(before_encoded["attention_mask"][0].sum().item()),
                        "after": int(after_encoded["attention_mask"][0].sum().item()),
                    },
                    "trials": trial_rows,
                }
                result["episodes"].append(episode)
                result["episodes"].sort(key=lambda item: item["episode_id"])
                result["aggregate"] = aggregate_binary_trials(result["episodes"])
                atomic_write_json(checkpoint_path, result)
                print(
                    f"[{utc_now()}] episode {episode_id:02d}/{args.episodes}: "
                    f"before={before_prediction} "
                    f"v1={trial_rows[0]['after_prediction']} "
                    f"v2={trial_rows[1]['after_prediction']} "
                    f"shifts=({trial_rows[0]['correct_evidence_shift']:+.3f}, "
                    f"{trial_rows[1]['correct_evidence_shift']:+.3f})",
                    flush=True,
                )
                continue

            prompt = render_episode_prompt(tokenizer, sentence)
            site_positions, site_token_ids, site_pieces = final_period_token_positions(
                tokenizer, prompt, sentence, expected_occurrences=3
            )
            encoded = tokenizer(
                [prompt, prompt],
                add_special_tokens=False,
                padding=True,
                return_tensors="pt",
            ).to(model.device)

            v1_device = (v1 * alpha).to(device=model.device, dtype=parameter_dtype)
            v2_device = (v2 * alpha).to(device=model.device, dtype=parameter_dtype)
            demo_1, demo_2, test_site = site_positions
            controller.capture_positions = None
            controller.plan = [
                {demo_1: v1_device, demo_2: v2_device, test_site: v1_device},
                {demo_1: v1_device, demo_2: v2_device, test_site: v2_device},
            ]
            outputs = model(**encoded, use_cache=False, return_dict=True)
            controller.plan = None
            next_logits = outputs.logits[:, -1, :].float()
            candidate_ids = [candidate_tokens["A"]["id"], candidate_tokens["B"]["id"]]
            scored = next_logits[:, candidate_ids].detach().cpu()

            trial_rows: list[dict[str, Any]] = []
            for row, (test_vector, correct_option, correct_label) in enumerate(
                (("v1", "A", "dax"), ("v2", "B", "wug"))
            ):
                logit_a = float(scored[row, 0].item())
                logit_b = float(scored[row, 1].item())
                predicted_option = "A" if logit_a > logit_b else "B"
                predicted_label = "dax" if predicted_option == "A" else "wug"
                correct_logit = logit_a if correct_option == "A" else logit_b
                incorrect_logit = logit_b if correct_option == "A" else logit_a
                trial_rows.append(
                    {
                        "trial_id": f"E{episode_id:02d}-{test_vector.upper()}",
                        "episode_id": episode_id,
                        "sentence": sentence,
                        "test_vector": test_vector,
                        "correct_option": correct_option,
                        "correct_label": correct_label,
                        "predicted_option": predicted_option,
                        "predicted_label": predicted_label,
                        "correct": predicted_option == correct_option,
                        "logit_A": logit_a,
                        "logit_B": logit_b,
                        "raw_A_minus_B": logit_a - logit_b,
                        "margin": correct_logit - incorrect_logit,
                        "answer_prefix_last_token_id": int(encoded["input_ids"][row, -1].item()),
                        "answer_prefix_last_token_piece": tokenizer.decode(
                            [int(encoded["input_ids"][row, -1].item())],
                            clean_up_tokenization_spaces=False,
                        ),
                    }
                )

            episode = {
                "episode_id": episode_id,
                "sentence": sentence,
                "vector_seed": vector_seed,
                "vector_pair": {
                    "v1": vector_summary(v1),
                    "v2": vector_summary(v2),
                    "dot_product": float(torch.dot(v1, v2).item()),
                    "cosine_similarity": float(
                        torch.dot(v1, v2).item() / (v1.norm().item() * v2.norm().item())
                    ),
                },
                "injection_sites": [
                    {
                        "role": "demonstration_1",
                        "position": demo_1,
                        "token_id": site_token_ids[0],
                        "decoded_piece": site_pieces[0],
                        "vector": "v1",
                        "label": "dax",
                    },
                    {
                        "role": "demonstration_2",
                        "position": demo_2,
                        "token_id": site_token_ids[1],
                        "decoded_piece": site_pieces[1],
                        "vector": "v2",
                        "label": "wug",
                    },
                    {
                        "role": "test",
                        "position": test_site,
                        "token_id": site_token_ids[2],
                        "decoded_piece": site_pieces[2],
                        "vector": "varies by paired trial",
                        "label": "unknown to model",
                    },
                ],
                "prompt_token_count": int(encoded["attention_mask"][0].sum().item()),
                "trials": trial_rows,
            }
            result["episodes"].append(episode)
            result["episodes"].sort(key=lambda item: item["episode_id"])
            result["aggregate"] = aggregate_trials(result["episodes"])
            atomic_write_json(checkpoint_path, result)
            print(
                f"[{utc_now()}] episode {episode_id:02d}/{args.episodes}: "
                f"v1={'✓' if trial_rows[0]['correct'] else '×'} "
                f"v2={'✓' if trial_rows[1]['correct'] else '×'} "
                f"margins=({trial_rows[0]['margin']:+.3f}, {trial_rows[1]['margin']:+.3f})",
                flush=True,
            )

        result["aggregate"] = (
            aggregate_binary_trials(result["episodes"])
            if is_binary
            else aggregate_trials(result["episodes"])
        )
        result["status"] = "completed"
        result["run"]["completed_at_utc"] = utc_now()
        result["run"]["duration_seconds"] = time.time() - started
        np.savez_compressed(vectors_path, **all_vectors)
        atomic_write_json(final_path, result)
        atomic_write_json(checkpoint_path, result)
        aggregate = result["aggregate"]
        if is_binary:
            after = aggregate["after"]
            before = aggregate["before"]
            print(
                f"[{utc_now()}] complete: after={after['n_correct']}/{after['n_trials']} "
                f"accuracy={after['accuracy']:.4f} "
                f"95% CI=[{after['ci_95']['low']:.4f}, {after['ci_95']['high']:.4f}] "
                f"before_accuracy={before['accuracy']:.4f} "
                f"mean_evidence_shift={aggregate['mean_correct_evidence_shift']:+.4f}",
                flush=True,
            )
        else:
            print(
                f"[{utc_now()}] complete: {aggregate['n_correct']}/{aggregate['n_trials']} "
                f"accuracy={aggregate['accuracy']:.4f} "
                f"95% CI=[{aggregate['ci_95']['low']:.4f}, {aggregate['ci_95']['high']:.4f}] "
                f"mean_margin={aggregate['mean_margin']:+.4f}",
                flush=True,
            )
        print(f"results: {final_path}", flush=True)
        print(f"vectors: {vectors_path}", flush=True)
        return 0
    finally:
        controller.plan = None
        controller.capture_positions = None
        hook_handle.remove()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"FATAL: {type(error).__name__}: {error}", file=sys.stderr, flush=True)
        raise
