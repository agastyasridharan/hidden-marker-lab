#!/usr/bin/env python3
"""Aggregate base and multi-seed introspection fine-tuning evaluations."""

from __future__ import annotations

import argparse
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

import numpy as np


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def primary(evaluation: dict[str, Any]) -> dict[str, Any]:
    return next(condition for condition in evaluation["conditions"] if condition.get("primary"))


def trial_key(trial: dict[str, Any]) -> tuple[Any, ...]:
    return (
        trial["episode_id"], trial["test_vector"], trial["mapping_swap"],
        trial["demo_reverse"], trial["option_reverse"],
    )


def condition_key(condition: dict[str, Any]) -> tuple[Any, ...]:
    return (
        condition["layer"], condition["rho"], condition["vector_family"],
        condition["carrier_mode"], condition["control"],
    )


def binned_training_curve(path: Path, width: int = 25) -> list[dict[str, Any]]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]
    result: list[dict[str, Any]] = []
    for start in range(0, len(rows), width):
        chunk = rows[start:start + width]
        result.append({
            "step": int(chunk[-1]["step"]),
            "objective": chunk[-1]["objective"],
            "mean_loss": statistics.fmean(float(row["loss"]) for row in chunk),
            "mean_batch_accuracy": statistics.fmean(float(row["accuracy"]) for row in chunk),
            "mean_rho": statistics.fmean(float(row["rho"]) for row in chunk),
            "learning_rate": float(chunk[-1]["learning_rate"]),
        })
    return result


def bootstrap_paired_improvement(
    base_trials: list[dict[str, Any]],
    fixed_trials: list[list[dict[str, Any]]],
    seed: int = 20260820,
) -> dict[str, Any]:
    base = {trial_key(trial): float(trial["correct"]) for trial in base_trials}
    trained_maps = [
        {trial_key(trial): float(trial["correct"]) for trial in trials}
        for trials in fixed_trials
    ]
    by_episode: dict[int, list[float]] = defaultdict(list)
    for key, base_correct in base.items():
        trained_correct = statistics.fmean(trained[key] for trained in trained_maps)
        by_episode[int(key[0])].append(trained_correct - base_correct)
    episode_differences = np.array([
        statistics.fmean(values) for values in by_episode.values()
    ], dtype=np.float64)
    rng = np.random.default_rng(seed)
    samples = np.empty(10_000, dtype=np.float64)
    for index in range(len(samples)):
        selected = rng.integers(0, len(episode_differences), size=len(episode_differences))
        samples[index] = episode_differences[selected].mean()
    return {
        "mean_accuracy_difference": float(episode_differences.mean()),
        "cluster_bootstrap_ci_95": [
            float(np.quantile(samples, 0.025)),
            float(np.quantile(samples, 0.975)),
        ],
        "cluster_unit": "base episode, after averaging transformations and training seeds",
    }


def aggregate_conditions(evaluations: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[tuple[Any, dict[str, Any]]]] = defaultdict(list)
    for evaluation in evaluations:
        for condition in evaluation["conditions"]:
            grouped[condition_key(condition)].append((
                evaluation["adapter_config"].get("seed"), condition,
            ))
    rows: list[dict[str, Any]] = []
    for key, entries in sorted(grouped.items(), key=lambda item: tuple(map(str, item[0]))):
        layer, rho, family, carrier_mode, control = key
        conditions = [entry[1] for entry in entries]
        accuracies = [float(condition["accuracy"]) for condition in conditions]
        margins = [float(condition["mean_margin"]) for condition in conditions]
        rows.append({
            "layer": layer,
            "rho": rho,
            "vector_family": family,
            "carrier_mode": carrier_mode,
            "control": control,
            "mean_accuracy": statistics.fmean(accuracies),
            "min_accuracy": min(accuracies),
            "max_accuracy": max(accuracies),
            "accuracy_std_across_seeds": statistics.stdev(accuracies) if len(accuracies) > 1 else 0.0,
            "mean_margin": statistics.fmean(margins),
            "per_seed": [
                {
                    "training_seed": training_seed,
                    "accuracy": condition["accuracy"],
                    "mean_margin": condition["mean_margin"],
                    "n_trials": condition["n_trials"],
                }
                for training_seed, condition in entries
            ],
        })
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--audit-output", type=Path)
    args = parser.parse_args()

    base_evaluation = read_json(args.root / "base" / "evaluation-results.json")
    fixed_directories = sorted(path for path in args.root.glob("seed-*") if path.is_dir())
    random_directory = args.root / "random-layer"
    fixed_evaluations = [read_json(path / "evaluation-results.json") for path in fixed_directories]
    random_evaluation = read_json(random_directory / "evaluation-results.json")
    fixed_primary = [primary(evaluation) for evaluation in fixed_evaluations]
    base_primary = primary(base_evaluation)
    random_primary = primary(random_evaluation)
    fixed_accuracies = [float(condition["accuracy"]) for condition in fixed_primary]

    runs: list[dict[str, Any]] = []
    for directory, evaluation, condition in zip(fixed_directories, fixed_evaluations, fixed_primary):
        metadata = read_json(directory / "run-metadata.json")
        runs.append({
            "training_seed": metadata["seed"],
            "condition": "fixed layer 20",
            "training": metadata,
            "primary": {key: value for key, value in condition.items() if key != "trials"},
            "curve": binned_training_curve(directory / "training-log.jsonl"),
        })
    random_metadata = read_json(random_directory / "run-metadata.json")
    runs.append({
        "training_seed": random_metadata["seed"],
        "condition": "random layers 16, 20, 24",
        "training": random_metadata,
        "primary": {key: value for key, value in random_primary.items() if key != "trials"},
        "curve": binned_training_curve(random_directory / "training-log.jsonl"),
    })

    audit_trials: list[dict[str, Any]] = []
    for label, evaluation in [("base", base_evaluation), *[
        (f"seed-{evaluation['adapter_config'].get('seed')}", evaluation)
        for evaluation in fixed_evaluations
    ], ("random-layer", random_evaluation)]:
        for trial in evaluation["primary_trials"]:
            audit_trials.append({"model_condition": label, **trial})

    artifact = {
        "schema_version": 1,
        "status": "completed",
        "title": "In-context matching after introspection fine-tuning",
        "model_id": base_evaluation["model_id"],
        "evaluation_seed": base_evaluation["evaluation_seed"],
        "protocol": {
            "primary": (
                "Fresh Gaussian FP32 QR pairs; held-out nonce labels and a disjoint carrier "
                "content-phrase pool; block 20 "
                "resid_pre at the carrier final period; rho=0.1; full 8-element "
                "mapping/demo/option counterfactual orbit; both test directions."
            ),
            "training": (
                "Online fresh vectors with localization and same/different curricula, followed "
                "by arbitrary label binding and an anneal from rho 0.5-2.0 to rho 0.02-0.2."
            ),
            "interpretation_limit": (
                "The result tests trained functional access to internal perturbations. It does "
                "not establish subjective introspection."
            ),
        },
        "aggregate": {
            "base_accuracy": base_primary["accuracy"],
            "fixed_seed_mean_accuracy": statistics.fmean(fixed_accuracies),
            "fixed_seed_min_accuracy": min(fixed_accuracies),
            "fixed_seed_max_accuracy": max(fixed_accuracies),
            "fixed_seed_accuracy_std": statistics.stdev(fixed_accuracies),
            "random_layer_accuracy": random_primary["accuracy"],
            "paired_improvement": bootstrap_paired_improvement(
                base_evaluation["primary_trials"],
                [evaluation["primary_trials"] for evaluation in fixed_evaluations],
            ),
            "mean_counterfactual_orbit_success": statistics.fmean(
                condition["complete_counterfactual_orbit_success_rate"]
                for condition in fixed_primary
            ),
            "all_fixed_seeds_above_75_percent": all(accuracy > 0.75 for accuracy in fixed_accuracies),
        },
        "base_primary": {key: value for key, value in base_primary.items() if key != "trials"},
        "runs": runs,
        "fixed_condition_matrix": aggregate_conditions(fixed_evaluations),
        "random_layer_conditions": random_evaluation["conditions"],
        "candidate_tokens": base_evaluation["candidate_tokens"],
        "audit": {
            "trial_count": len(audit_trials),
            "url": "/data/introspection-training-audit.json",
            "unit": "one model × episode × test vector × counterfactual transform",
        },
    }
    audit_artifact = {
        "schema_version": 1,
        "status": "completed",
        "evaluation_seed": base_evaluation["evaluation_seed"],
        "trials": audit_trials,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(artifact, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    audit_output = args.audit_output or args.output.with_name("introspection-training-audit.json")
    audit_output.parent.mkdir(parents=True, exist_ok=True)
    audit_output.write_text(
        json.dumps(audit_artifact, separators=(",", ":"), ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(artifact["aggregate"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
