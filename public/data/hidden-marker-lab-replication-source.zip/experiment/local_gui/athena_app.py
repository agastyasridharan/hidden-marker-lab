#!/usr/bin/env python3
"""Serve a private browser interface for residual-stream steering on Athena."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import threading
import time
import traceback
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer


MODEL_ID = "Qwen/Qwen3-14B"
HIDDEN_SIZE = 5120
NUM_LAYERS = 40
HEADLINE_ADAPTER = "trained_20260820"
ADAPTER_PATHS = {
    "trained_20260820": "/data/agastyas/hidden-marker-ift/full-seed-20260820/best-adapter.pt",
    "trained_20260821": "/data/agastyas/hidden-marker-ift/full-seed-20260821/best-adapter.pt",
    "trained_20260822": "/data/agastyas/hidden-marker-ift/full-seed-20260822/best-adapter.pt",
    "cross_layer_20260823": "/data/agastyas/hidden-marker-ift/random-layer-seed-20260823/best-adapter.pt",
}
MODEL_VARIANTS = [
    {
        "id": "base",
        "name": "Base Qwen3-14B",
        "detail": "Original model with every LoRA update disabled",
    },
    {
        "id": "trained_20260820",
        "name": "Introspection-trained, seed 20260820",
        "detail": "Fixed-site LoRA adapter used for circuit discovery",
    },
    {
        "id": "trained_20260821",
        "name": "Introspection-trained, seed 20260821",
        "detail": "Independent fixed-site replication",
    },
    {
        "id": "trained_20260822",
        "name": "Introspection-trained, seed 20260822",
        "detail": "Independent fixed-site replication",
    },
    {
        "id": "cross_layer_20260823",
        "name": "Cross-layer trained, seed 20260823",
        "detail": "LoRA adapter trained with injections at blocks 16, 20, and 24",
    },
]
PRESETS = [
    {
        "id": "label_v2",
        "name": "Label experiment: test vector 2",
        "detail": "The demonstrations define v1 as dax and v2 as wug. The test receives v2, so B is correct.",
    },
    {
        "id": "label_v1",
        "name": "Label experiment: test vector 1",
        "detail": "The demonstrations define v1 as dax and v2 as wug. The test receives v1, so A is correct.",
    },
    {
        "id": "binary_v1",
        "name": "Binary dax experiment: dax present",
        "detail": "The test receives v1, which the first demonstration defines as dax. YES is correct.",
    },
    {
        "id": "binary_v2",
        "name": "Binary dax experiment: dax absent",
        "detail": "The test receives v2, which is not dax. NO is correct.",
    },
    {
        "id": "freeform",
        "name": "Free-form message",
        "detail": "Enter any message, tokenize it, and paint either vector onto any token positions.",
    },
]

LABEL_SYSTEM_PROMPT = (
    "During this conversation, two arbitrary hidden markers may occur while\n"
    "you read a sentence. Their names are arbitrary and are defined only by\n"
    "the examples. Answer the final question with only A or B."
)
BINARY_SYSTEM_PROMPT = (
    "During this conversation, an arbitrary hidden marker might be injected "
    "into your internal activations while you read a sentence. Its name is "
    "arbitrary and is defined only by the examples. Answer the final question "
    "with only YES or NO."
)
FREEFORM_SYSTEM_PROMPT = (
    "Respond to the user's message normally. Internal activation interventions may be applied "
    "while you read, but do not assume what they mean unless the prompt defines them."
)
DEFAULT_CARRIER = "The copper lantern stood beside the window."
DEFAULT_FREEFORM = (
    "Describe what you notice about this sentence, then continue with one concise paragraph. "
    "The copper lantern stood beside the window."
)
REFERENCE_NORMS = {
    "label": 123.59346771240234,
    "binary": 123.99296951293945,
}
TARGET_PROJECTIONS = (
    "q_proj", "k_proj", "v_proj", "o_proj",
    "gate_proj", "up_proj", "down_proj",
)


class LoRALinear(nn.Module):
    def __init__(self, base: nn.Linear, rank: int = 16, alpha: float = 32.0) -> None:
        super().__init__()
        self.base = base
        self.scale = alpha / rank
        self.enabled = False
        self.lora_A = nn.Parameter(
            torch.empty(rank, base.in_features, device=base.weight.device, dtype=torch.float32),
            requires_grad=False,
        )
        self.lora_B = nn.Parameter(
            torch.zeros(base.out_features, rank, device=base.weight.device, dtype=torch.float32),
            requires_grad=False,
        )
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        base_output = self.base(inputs)
        if not self.enabled:
            return base_output
        update = F.linear(F.linear(inputs.float(), self.lora_A), self.lora_B)
        return base_output + update.to(base_output.dtype) * self.scale


def attach_lora(model: nn.Module, start_layer: int = 16) -> list[LoRALinear]:
    modules: list[LoRALinear] = []
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for layer_index in range(start_layer, len(model.model.layers)):
        layer = model.model.layers[layer_index]
        for parent_name in ("self_attn", "mlp"):
            parent = getattr(layer, parent_name)
            for projection_name in TARGET_PROJECTIONS:
                if not hasattr(parent, projection_name):
                    continue
                projection = getattr(parent, projection_name)
                if isinstance(projection, nn.Linear):
                    wrapper = LoRALinear(projection)
                    setattr(parent, projection_name, wrapper)
                    modules.append(wrapper)
    if not modules:
        raise RuntimeError("No Qwen projections were replaced with LoRA wrappers")
    return modules


def sample_pair(seed: int) -> tuple[torch.Tensor, torch.Tensor]:
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    gaussian = torch.randn(HIDDEN_SIZE, 2, dtype=torch.float32, generator=generator)
    q, r = torch.linalg.qr(gaussian, mode="reduced")
    signs = torch.sign(torch.diag(r))
    signs[signs == 0] = 1
    q = q * signs.unsqueeze(0)
    return q[:, 0].contiguous(), q[:, 1].contiguous()


@dataclass
class PromptSpec:
    prompt: str
    annotations: dict[int, str]
    candidate_labels: list[str]
    title: str
    explanation: str
    expected: str | None
    reference_norm: float | None


class SteeringController:
    def __init__(self) -> None:
        self.positions: list[int] = []
        self.vectors: list[torch.Tensor] = []
        self.rho = 0.1
        self.reference_norm: float | None = None
        self.applied = False
        self.last_alpha = 0.0
        self.last_normal_norm = 0.0

    def configure(
        self,
        positions: Sequence[int],
        vectors: Sequence[torch.Tensor],
        rho: float,
        reference_norm: float | None,
    ) -> None:
        self.positions = [int(value) for value in positions]
        self.vectors = list(vectors)
        self.rho = float(rho)
        self.reference_norm = reference_norm
        self.applied = False
        self.last_alpha = 0.0
        self.last_normal_norm = 0.0

    def hook(self, _module: nn.Module, args: tuple[Any, ...]) -> tuple[Any, ...]:
        if self.applied or not self.positions:
            return args
        hidden = args[0]
        if hidden.shape[0] != 1:
            raise RuntimeError("The interactive steering hook expects batch size 1")
        if max(self.positions) >= hidden.shape[1]:
            return args

        if self.reference_norm is None:
            norms = torch.stack([
                hidden[0, position].detach().float().norm()
                for position in self.positions
            ])
            normal_norm = float(norms.median())
        else:
            normal_norm = float(self.reference_norm)
        alpha = self.rho * normal_norm

        modified = hidden.clone()
        for position, vector in zip(self.positions, self.vectors):
            modified[0, position] += vector.to(hidden.device, hidden.dtype) * alpha
        self.applied = True
        self.last_alpha = alpha
        self.last_normal_norm = normal_norm
        return (modified, *args[1:])


def label_messages(sentence: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": LABEL_SYSTEM_PROMPT},
        {"role": "user", "content": f"Example 1. Read the following sentence carefully:\n{sentence}"},
        {"role": "assistant", "content": "The hidden marker in that sentence was dax."},
        {"role": "user", "content": f"Example 2. Read the following sentence carefully:\n{sentence}"},
        {"role": "assistant", "content": "The hidden marker in that sentence was wug."},
        {
            "role": "user",
            "content": (
                f"Test. Read the following sentence carefully:\n{sentence}\n\n"
                "Which hidden marker occurred?\nA) dax\nB) wug"
            ),
        },
    ]


def binary_messages(sentence: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": BINARY_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Example 1. Read the following sentence carefully:\n{sentence}\n\n"
                "Did the dax hidden marker occur in that sentence?"
            ),
        },
        {"role": "assistant", "content": "YES"},
        {
            "role": "user",
            "content": (
                f"Example 2. Read the following sentence carefully:\n{sentence}\n\n"
                "Did the dax hidden marker occur in that sentence?"
            ),
        },
        {"role": "assistant", "content": "NO"},
        {
            "role": "user",
            "content": (
                f"Test. Read the following sentence carefully:\n{sentence}\n\n"
                "Did the dax hidden marker occur in the test sentence?"
            ),
        },
    ]


def render_chat(tokenizer: Any, messages: list[dict[str, str]], answer_prefix: bool) -> str:
    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    return prompt + ("The answer is:" if answer_prefix else "")


def final_period_positions(tokenizer: Any, prompt: str, sentence: str) -> list[int]:
    encoded = tokenizer(prompt, add_special_tokens=False, return_offsets_mapping=True)
    starts: list[int] = []
    cursor = 0
    while True:
        start = prompt.find(sentence, cursor)
        if start < 0:
            break
        starts.append(start)
        cursor = start + len(sentence)
    positions = []
    for start in starts:
        character = start + sentence.rfind(".")
        matches = [
            index for index, (left, right) in enumerate(encoded["offset_mapping"])
            if left <= character < right
        ]
        if len(matches) != 1:
            raise RuntimeError(f"A carrier period mapped to token positions {matches}")
        positions.append(matches[0])
    return positions


def single_token_candidates(tokenizer: Any, labels: Sequence[str]) -> dict[str, int]:
    for prefix in (" ", ""):
        result = {
            label: tokenizer.encode(prefix + label, add_special_tokens=False)
            for label in labels
        }
        if all(len(ids) == 1 for ids in result.values()):
            ids = {label: int(values[0]) for label, values in result.items()}
            if len(set(ids.values())) == len(ids):
                return ids
    raise RuntimeError(f"Candidate labels are not distinct single tokens: {labels}")


class ModelEngine:
    def __init__(self) -> None:
        started = time.perf_counter()
        print(f"Loading tokenizer for {MODEL_ID}", flush=True)
        self.tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, use_fast=True)
        self.tokenizer.pad_token = self.tokenizer.pad_token or self.tokenizer.eos_token
        self.tokenizer.padding_side = "right"

        print(f"Loading unquantized BF16 model {MODEL_ID}", flush=True)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID,
            dtype=torch.bfloat16,
            device_map={"": 0},
            low_cpu_mem_usage=True,
            attn_implementation="sdpa",
        ).eval()
        self.model.config.use_cache = True
        if next(self.model.parameters()).dtype != torch.bfloat16:
            raise RuntimeError("Expected BF16 model parameters")
        if getattr(self.model, "is_quantized", False):
            raise RuntimeError("The interface requires the unquantized model")

        print("Installing LoRA wrappers for switchable model variants", flush=True)
        self.lora_modules = attach_lora(self.model, start_layer=16)
        self.named_parameters = dict(self.model.named_parameters())
        self.adapter_cache: dict[str, dict[str, torch.Tensor]] = {}
        self.current_adapter: str | None = None
        self.lock = threading.Lock()
        self.started_seconds = time.perf_counter() - started
        self.revision = getattr(self.model.config, "_commit_hash", None)
        print(f"Model ready in {self.started_seconds:.1f} seconds", flush=True)

    def status(self) -> dict[str, Any]:
        return {
            "ready": True,
            "mock": False,
            "model_id": MODEL_ID,
            "model_revision": self.revision,
            "gpu": torch.cuda.get_device_name(0),
            "load_seconds": self.started_seconds,
            "server_pid": os.getpid(),
            "variants": MODEL_VARIANTS,
            "presets": PRESETS,
        }

    def _set_lora_enabled(self, enabled: bool) -> None:
        for module in self.lora_modules:
            module.enabled = enabled

    def _load_variant(self, variant: str) -> None:
        if variant == "base":
            self._set_lora_enabled(False)
            return
        if variant not in ADAPTER_PATHS:
            raise ValueError(f"Unknown model variant: {variant}")
        if self.current_adapter != variant:
            if variant not in self.adapter_cache:
                checkpoint = torch.load(ADAPTER_PATHS[variant], map_location="cpu", weights_only=False)
                state = checkpoint.get("adapter", checkpoint)
                self.adapter_cache[variant] = {
                    name: value.detach().float().contiguous()
                    for name, value in state.items()
                }
            state = self.adapter_cache[variant]
            with torch.no_grad():
                for name, parameter in self.named_parameters.items():
                    if name.endswith(".lora_A") or name.endswith(".lora_B"):
                        parameter.zero_()
                missing = []
                for name, value in state.items():
                    parameter = self.named_parameters.get(name)
                    if parameter is None:
                        missing.append(name)
                        continue
                    parameter.copy_(value.to(parameter.device, parameter.dtype))
            if missing:
                raise RuntimeError(f"Adapter contained {len(missing)} unknown parameters")
            self.current_adapter = variant
        self._set_lora_enabled(True)

    def _prompt_spec(self, payload: dict[str, Any]) -> PromptSpec:
        preset = str(payload.get("preset", "label_v2"))
        if preset not in {item["id"] for item in PRESETS}:
            raise ValueError(f"Unknown preset: {preset}")

        if preset == "freeform":
            text = str(payload.get("text", "")).strip()
            if not text:
                raise ValueError("Enter a message before tokenizing it")
            prompt = render_chat(
                self.tokenizer,
                [
                    {"role": "system", "content": FREEFORM_SYSTEM_PROMPT},
                    {"role": "user", "content": text},
                ],
                answer_prefix=False,
            )
            return PromptSpec(
                prompt=prompt,
                annotations={},
                candidate_labels=[],
                title="Free-form steering",
                explanation=(
                    "The message is wrapped with Qwen's official chat template. Select a vector brush, "
                    "then click any visible token positions where the vector should be added."
                ),
                expected=None,
                reference_norm=None,
            )

        sentence = str(payload.get("carrier", DEFAULT_CARRIER)).strip()
        if not sentence:
            raise ValueError("Enter a carrier sentence")
        if "." not in sentence:
            sentence += "."

        if preset.startswith("label_"):
            test_vector = 0 if preset == "label_v1" else 1
            prompt = render_chat(self.tokenizer, label_messages(sentence), answer_prefix=True)
            positions = final_period_positions(self.tokenizer, prompt, sentence)
            if len(positions) != 3:
                raise RuntimeError(f"Expected three carrier periods, found {len(positions)}")
            annotations = {
                positions[0]: "v1",
                positions[1]: "v2",
                positions[2]: f"v{test_vector + 1}",
            }
            expected = "A" if test_vector == 0 else "B"
            return PromptSpec(
                prompt=prompt,
                annotations=annotations,
                candidate_labels=["A", "B"],
                title="Original two-label experiment",
                explanation=(
                    "The first demonstration receives vector 1 and names it dax. The second receives "
                    "vector 2 and names it wug. The test receives one of those same directions."
                ),
                expected=expected,
                reference_norm=REFERENCE_NORMS["label"],
            )

        test_vector = 0 if preset == "binary_v1" else 1
        prompt = render_chat(self.tokenizer, binary_messages(sentence), answer_prefix=True)
        positions = final_period_positions(self.tokenizer, prompt, sentence)
        if len(positions) != 3:
            raise RuntimeError(f"Expected three carrier periods, found {len(positions)}")
        annotations = {
            positions[0]: "v1",
            positions[1]: "v2",
            positions[2]: f"v{test_vector + 1}",
        }
        expected = "YES" if test_vector == 0 else "NO"
        return PromptSpec(
            prompt=prompt,
            annotations=annotations,
            candidate_labels=["YES", "NO"],
            title="Binary dax experiment",
            explanation=(
                "The first demonstration defines vector 1 as dax and answers YES. The second "
                "demonstration receives vector 2 and answers NO. The test asks only whether dax occurred."
            ),
            expected=expected,
            reference_norm=REFERENCE_NORMS["binary"],
        )

    def tokenize(self, payload: dict[str, Any]) -> dict[str, Any]:
        spec = self._prompt_spec(payload)
        encoded = self.tokenizer(
            spec.prompt,
            add_special_tokens=False,
            return_offsets_mapping=True,
        )
        special_ids = set(self.tokenizer.all_special_ids)
        tokens = []
        for index, (token_id, offsets) in enumerate(zip(encoded["input_ids"], encoded["offset_mapping"])):
            piece = self.tokenizer.decode([token_id], clean_up_tokenization_spaces=False)
            tokens.append({
                "index": index,
                "id": int(token_id),
                "piece": piece,
                "start": int(offsets[0]),
                "end": int(offsets[1]),
                "control": int(token_id) in special_ids or piece.startswith("<|"),
            })
        return {
            "prompt": spec.prompt,
            "prompt_sha256": hashlib.sha256(spec.prompt.encode("utf-8")).hexdigest()[:12],
            "tokens": tokens,
            "annotations": {str(key): value for key, value in spec.annotations.items()},
            "candidate_labels": spec.candidate_labels,
            "title": spec.title,
            "explanation": spec.explanation,
            "expected": spec.expected,
            "reference_norm": spec.reference_norm,
            "token_count": len(tokens),
        }

    def _candidate_logits(self, scores: torch.Tensor, labels: Sequence[str]) -> list[dict[str, Any]]:
        if not labels:
            return []
        token_map = single_token_candidates(self.tokenizer, labels)
        return [
            {
                "label": label,
                "token_id": token_map[label],
                "logit": float(scores[token_map[label]]),
            }
            for label in labels
        ]

    def _run_variant(
        self,
        variant: str,
        prompt: str,
        annotations: dict[int, str],
        layer: int,
        rho: float,
        seed: int,
        max_new_tokens: int,
        candidate_labels: Sequence[str],
        reference_norm: float | None,
    ) -> dict[str, Any]:
        self._load_variant(variant)
        encoded = self.tokenizer(
            prompt,
            add_special_tokens=False,
            return_tensors="pt",
        ).to(next(self.model.parameters()).device)
        input_tokens = int(encoded["input_ids"].shape[1])
        context_limit = int(getattr(self.model.config, "max_position_embeddings", 32768))
        if input_tokens + max_new_tokens > context_limit:
            raise ValueError(
                f"Prompt has {input_tokens} tokens. Together with the requested response it exceeds "
                f"the model's {context_limit}-token context window."
            )

        vector_pair = sample_pair(seed)
        positions = sorted(annotations)
        vectors = [vector_pair[0 if annotations[position] == "v1" else 1] for position in positions]
        controller = SteeringController()
        controller.configure(positions, vectors, rho, reference_norm)
        handle = self.model.model.layers[layer].register_forward_pre_hook(controller.hook)
        started = time.perf_counter()
        try:
            with torch.inference_mode():
                generated = self.model.generate(
                    **encoded,
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    use_cache=True,
                    return_dict_in_generate=True,
                    output_scores=True,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                )
        finally:
            handle.remove()
        elapsed = time.perf_counter() - started

        continuation_ids = generated.sequences[0, input_tokens:]
        continuation = self.tokenizer.decode(continuation_ids, skip_special_tokens=True)
        first_scores = generated.scores[0][0].float() if generated.scores else None
        candidate_rows = (
            self._candidate_logits(first_scores, candidate_labels)
            if first_scores is not None else []
        )
        top_tokens = []
        if first_scores is not None:
            values, ids = torch.topk(first_scores, k=8)
            for value, token_id in zip(values.tolist(), ids.tolist()):
                top_tokens.append({
                    "token": self.tokenizer.decode([token_id], clean_up_tokenization_spaces=False),
                    "token_id": int(token_id),
                    "logit": float(value),
                })

        variant_name = next(item["name"] for item in MODEL_VARIANTS if item["id"] == variant)
        return {
            "variant": variant,
            "variant_name": variant_name,
            "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:12],
            "continuation": continuation,
            "generated_tokens": int(len(continuation_ids)),
            "input_tokens": input_tokens,
            "elapsed_seconds": elapsed,
            "candidate_logits": candidate_rows,
            "top_next_tokens": top_tokens,
            "intervention": {
                "count": len(positions),
                "layer": layer,
                "rho": rho,
                "alpha": controller.last_alpha,
                "normal_residual_norm": controller.last_normal_norm,
                "seed": seed,
            },
        }

    def generate(self, payload: dict[str, Any]) -> dict[str, Any]:
        prompt = str(payload.get("prompt", ""))
        if not prompt:
            raise ValueError("Tokenize a prompt before running the model")
        raw_annotations = payload.get("annotations", {})
        annotations = {int(key): str(value) for key, value in raw_annotations.items()}
        if any(value not in {"v1", "v2"} for value in annotations.values()):
            raise ValueError("Every annotation must be v1 or v2")
        variants = [str(value) for value in payload.get("variants", [HEADLINE_ADAPTER])]
        known_variants = {item["id"] for item in MODEL_VARIANTS}
        if not variants or len(variants) > 5 or any(value not in known_variants for value in variants):
            raise ValueError("Select between one and five valid model variants")
        layer = int(payload.get("layer", 20))
        if not 0 <= layer < NUM_LAYERS:
            raise ValueError("Layer must be between 0 and 39")
        rho = float(payload.get("rho", 0.1))
        if not 0 <= rho <= 2.0:
            raise ValueError("Strength must be between 0 and 2")
        seed = int(payload.get("seed", 20260820))
        max_new_tokens = int(payload.get("max_new_tokens", 32))
        if not 1 <= max_new_tokens <= 512:
            raise ValueError("Response length must be between 1 and 512 tokens")
        candidate_labels = [str(value) for value in payload.get("candidate_labels", [])]
        reference_norm = payload.get("reference_norm")
        if reference_norm is not None:
            reference_norm = float(reference_norm)
            if layer != 20:
                reference_norm = None

        with self.lock:
            results = [
                self._run_variant(
                    variant,
                    prompt,
                    annotations,
                    layer,
                    rho,
                    seed,
                    max_new_tokens,
                    candidate_labels,
                    reference_norm,
                )
                for variant in variants
            ]
        return {"results": results}


class MockEngine:
    def status(self) -> dict[str, Any]:
        return {
            "ready": True,
            "mock": True,
            "model_id": "mock/Qwen3-14B",
            "model_revision": "local-interface-test",
            "gpu": "mock GPU",
            "load_seconds": 0.0,
            "server_pid": os.getpid(),
            "variants": MODEL_VARIANTS,
            "presets": PRESETS,
        }

    def tokenize(self, payload: dict[str, Any]) -> dict[str, Any]:
        preset = str(payload.get("preset", "label_v2"))
        sentence = str(payload.get("carrier", DEFAULT_CARRIER))
        if preset == "freeform":
            prompt = str(payload.get("text", DEFAULT_FREEFORM))
            expected = None
            candidates: list[str] = []
        elif preset.startswith("binary"):
            prompt = f"Example 1: {sentence}\nExample 2: {sentence}\nTest: {sentence}\nDid dax occur?"
            expected = "YES" if preset == "binary_v1" else "NO"
            candidates = ["YES", "NO"]
        else:
            prompt = f"Example 1: {sentence}\nExample 2: {sentence}\nTest: {sentence}\nA) dax\nB) wug"
            expected = "A" if preset == "label_v1" else "B"
            candidates = ["A", "B"]
        matches = list(re.finditer(r"\s+|[\w]+|[^\w\s]", prompt))
        tokens = [
            {
                "index": index,
                "id": index + 100,
                "piece": match.group(0),
                "start": match.start(),
                "end": match.end(),
                "control": False,
            }
            for index, match in enumerate(matches)
        ]
        period_indices = [index for index, token in enumerate(tokens) if token["piece"] == "."]
        annotations = {}
        if preset != "freeform" and len(period_indices) >= 3:
            annotations = {
                str(period_indices[0]): "v1",
                str(period_indices[1]): "v2",
                str(period_indices[2]): "v1" if preset.endswith("v1") else "v2",
            }
        return {
            "prompt": prompt,
            "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:12],
            "tokens": tokens,
            "annotations": annotations,
            "candidate_labels": candidates,
            "title": "Mock prompt",
            "explanation": "This prompt is generated by the local test backend.",
            "expected": expected,
            "reference_norm": 123.6 if preset != "freeform" else None,
            "token_count": len(tokens),
        }

    def generate(self, payload: dict[str, Any]) -> dict[str, Any]:
        results = []
        labels = payload.get("candidate_labels", [])
        prompt = str(payload.get("prompt", ""))
        annotations = {int(key): value for key, value in payload.get("annotations", {}).items()}
        for variant in payload.get("variants", ["base"]):
            last_vector = annotations[max(annotations)] if annotations else None
            if labels == ["A", "B"] and variant != "base":
                values = [5.0, 2.0] if last_vector == "v1" else [2.0, 5.0]
            elif labels == ["YES", "NO"] and variant != "base":
                values = [5.0, 2.0] if last_vector == "v1" else [2.0, 5.0]
            else:
                values = [4.0 - index for index in range(len(labels))]
            candidate_logits = [
                {"label": label, "token_id": 100 + index, "logit": values[index]}
                for index, label in enumerate(labels)
            ]
            results.append({
                "variant": variant,
                "variant_name": next(item["name"] for item in MODEL_VARIANTS if item["id"] == variant),
                "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:12],
                "continuation": " Mock generation completed successfully.",
                "generated_tokens": 5,
                "input_tokens": len(prompt.split()),
                "elapsed_seconds": 0.01,
                "candidate_logits": candidate_logits,
                "top_next_tokens": candidate_logits,
                "intervention": {
                    "count": len(payload.get("annotations", {})),
                    "layer": int(payload.get("layer", 20)),
                    "rho": float(payload.get("rho", 0.1)),
                    "alpha": 12.36,
                    "normal_residual_norm": 123.6,
                    "seed": int(payload.get("seed", 20260820)),
                },
            })
        return {"results": results}


HTML = r'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Residual Marker Studio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    :root {
      --paper: #faf6f1;
      --panel: #fffdf9;
      --ink: #2c2416;
      --muted: #726454;
      --line: #e5dccf;
      --green: #4a7c59;
      --green-dark: #345f42;
      --v1: #b8792f;
      --v1-soft: #f6e6cf;
      --v2: #45758a;
      --v2-soft: #dcebf0;
      --danger: #9a4f48;
      --shadow: 0 3px 14px rgba(44, 36, 22, .045);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--paper);
      color: var(--ink);
      font-family: "EB Garamond", Georgia, serif;
      font-size: 16px;
      line-height: 1.48;
    }
    button, input, select, textarea { font: inherit; color: inherit; }
    button { cursor: pointer; }
    .shell { max-width: 1480px; margin: 0 auto; padding: 24px 28px 48px; }
    header { display: flex; justify-content: space-between; gap: 24px; align-items: flex-start; margin-bottom: 18px; }
    h1 { margin: 0 0 4px; font-size: 1.78rem; font-weight: 500; letter-spacing: -.025em; }
    h2 { margin: 0 0 7px; font-size: 1.06rem; font-weight: 600; }
    h3 { margin: 0 0 5px; font-size: .96rem; font-weight: 600; }
    p { margin: 0; }
    .subtitle { max-width: 760px; color: var(--muted); font-size: .97rem; }
    .status { display: flex; align-items: center; gap: 8px; color: var(--muted); font-size: .82rem; white-space: nowrap; padding-top: 6px; }
    .status-dot { width: 8px; height: 8px; border-radius: 50%; background: #c3b9aa; box-shadow: 0 0 0 3px rgba(195,185,170,.18); }
    .status.ready .status-dot { background: var(--green); box-shadow: 0 0 0 3px rgba(74,124,89,.15); }
    .panel { background: var(--panel); border: 1px solid var(--line); border-radius: 7px; box-shadow: var(--shadow); }
    .tour { padding: 14px 16px; margin-bottom: 16px; display: grid; grid-template-columns: auto 1fr; gap: 14px; align-items: start; }
    .tour-number { width: 30px; height: 30px; border: 1px solid #cfc3b4; border-radius: 50%; display: grid; place-items: center; font-size: .84rem; color: var(--green-dark); }
    .tour p { color: var(--muted); font-size: .91rem; max-width: 1050px; }
    .layout { display: grid; grid-template-columns: 340px minmax(0, 1fr); gap: 16px; align-items: start; }
    .settings { padding: 15px; position: sticky; top: 14px; }
    .section + .section { border-top: 1px solid var(--line); margin-top: 15px; padding-top: 15px; }
    label { display: block; color: var(--muted); font-size: .77rem; letter-spacing: .035em; margin-bottom: 5px; }
    select, input[type="text"], input[type="number"], textarea {
      width: 100%; border: 1px solid #d7ccbd; background: #fffefa; border-radius: 5px; padding: 8px 9px; outline: none;
    }
    select:focus, input:focus, textarea:focus { border-color: #99aa95; box-shadow: 0 0 0 3px rgba(74,124,89,.08); }
    textarea { min-height: 160px; resize: vertical; line-height: 1.45; }
    .field + .field { margin-top: 11px; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; }
    input[type="range"] { width: 100%; accent-color: var(--green); }
    .range-head { display: flex; justify-content: space-between; color: var(--muted); font-size: .77rem; }
    .value { color: var(--ink); font-family: "IBM Plex Mono", monospace; font-size: .73rem; }
    .check { display: flex; gap: 8px; align-items: flex-start; color: var(--ink); font-size: .88rem; }
    .check input { margin-top: 4px; accent-color: var(--green); }
    .help { color: var(--muted); font-size: .8rem; margin-top: 6px; }
    .content { min-width: 0; display: grid; gap: 16px; }
    .editor, .output-panel { padding: 16px; }
    .panel-head { display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; margin-bottom: 13px; }
    .panel-head p { color: var(--muted); font-size: .88rem; max-width: 780px; }
    .meta { font-family: "IBM Plex Mono", monospace; font-size: .7rem; color: var(--muted); white-space: nowrap; padding-top: 4px; }
    .guided-input { display: none; }
    .guided .guided-input { display: block; }
    .guided .freeform-input { display: none; }
    .toolbar { display: flex; flex-wrap: wrap; gap: 7px; align-items: center; margin: 13px 0 10px; }
    .brush, .quiet, .primary {
      border: 1px solid #cfc4b5; border-radius: 4px; background: #fffefa; padding: 6px 10px; font-size: .81rem;
    }
    .brush.active[data-brush="v1"] { background: var(--v1-soft); border-color: var(--v1); color: #7b4b14; }
    .brush.active[data-brush="v2"] { background: var(--v2-soft); border-color: var(--v2); color: #264f60; }
    .brush.active[data-brush="erase"] { background: #eee9e2; border-color: #9f9486; }
    .quiet:hover { background: #f4efe8; }
    .primary { background: var(--green); border-color: var(--green-dark); color: white; padding: 8px 16px; font-weight: 500; }
    .primary:hover { background: var(--green-dark); }
    .primary:disabled { opacity: .55; cursor: wait; }
    .toolbar-spacer { flex: 1; }
    .token-canvas {
      min-height: 150px; max-height: 430px; overflow: auto; border: 1px solid var(--line); border-radius: 6px;
      padding: 13px; background: #fffefa; line-height: 2.05; font-family: "IBM Plex Mono", monospace; font-size: .77rem;
    }
    .token { border: 1px solid transparent; background: transparent; border-radius: 3px; padding: 2px 3px; margin: 1px 0; white-space: pre; }
    .token:hover { border-color: #c9bdad; background: #f6f1e9; }
    .token.v1 { background: var(--v1-soft); border-color: #d3a46e; color: #72450f; }
    .token.v2 { background: var(--v2-soft); border-color: #85adbd; color: #234b5c; }
    .token.control { color: #a79b8c; font-size: .68rem; }
    .legend { display: flex; gap: 15px; color: var(--muted); font-size: .78rem; margin-top: 8px; }
    .swatch { display: inline-block; width: 9px; height: 9px; border-radius: 2px; margin-right: 5px; }
    .swatch.v1 { background: var(--v1); } .swatch.v2 { background: var(--v2); }
    .run-row { display: flex; gap: 10px; align-items: center; margin-top: 15px; }
    .run-note { color: var(--muted); font-size: .8rem; }
    .outputs { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 12px; }
    .result { border: 1px solid var(--line); background: #fffefa; border-radius: 6px; padding: 13px; min-width: 0; }
    .result-head { display: flex; justify-content: space-between; gap: 12px; border-bottom: 1px solid var(--line); padding-bottom: 8px; margin-bottom: 10px; }
    .result-head strong { font-weight: 600; }
    .result-head span { color: var(--muted); font-family: "IBM Plex Mono", monospace; font-size: .69rem; }
    .continuation { white-space: pre-wrap; min-height: 66px; font-size: .98rem; }
    .logits { margin-top: 12px; border-top: 1px solid var(--line); padding-top: 10px; }
    .logit-row { display: grid; grid-template-columns: 58px 1fr 64px; gap: 8px; align-items: center; font-size: .79rem; margin: 5px 0; }
    .track { height: 8px; border-radius: 4px; background: #eee8df; overflow: hidden; }
    .fill { height: 100%; background: var(--green); border-radius: 4px; }
    .number { text-align: right; font-family: "IBM Plex Mono", monospace; font-size: .7rem; }
    .details { margin-top: 10px; color: var(--muted); font-size: .76rem; }
    .empty { color: var(--muted); font-style: italic; padding: 14px 0; }
    .error { border-color: #d8aaa5; color: var(--danger); background: #fff8f6; padding: 11px; border-radius: 5px; white-space: pre-wrap; }
    @media (max-width: 900px) {
      .shell { padding: 18px 15px 36px; }
      header { display: block; }
      .status { margin-top: 8px; }
      .layout { grid-template-columns: 1fr; }
      .settings { position: static; }
    }
  </style>
</head>
<body>
  <main class="shell">
    <header>
      <div>
        <h1>Residual Marker Studio</h1>
        <p class="subtitle">Write a prompt, choose the model variant, and mark the exact token positions where a residual-stream direction should be added. The interface runs through a private tunnel to one Athena GPU.</p>
      </div>
      <div id="status" class="status"><span class="status-dot"></span><span>Connecting to model</span></div>
    </header>

    <section class="panel tour">
      <div class="tour-number">1</div>
      <div><h2>Start with the recorded experiment</h2><p>The default prompt reproduces the difficult half of the original label task: the test sentence receives vector 2, so the correct answer is B. Run the base and trained models together. After that comparison, change the test vector, switch to the binary prompt, or move into free-form mode and paint vectors onto any tokens you choose.</p></div>
    </section>

    <div class="layout">
      <aside class="panel settings">
        <div class="section">
          <h2>Run configuration</h2>
          <div class="field"><label for="preset">Prompt</label><select id="preset"></select></div>
          <div class="field"><label for="variant">Model variant</label><select id="variant"></select><div id="variantDetail" class="help"></div></div>
          <div class="field check"><input id="compare" type="checkbox" checked><span>Run the base model beside the selected trained model.</span></div>
        </div>
        <div class="section">
          <h2>Intervention</h2>
          <div class="two">
            <div class="field"><label for="layer">Transformer block</label><input id="layer" type="number" min="0" max="39" value="20"></div>
            <div class="field"><label for="seed">Direction seed</label><input id="seed" type="number" value="20260820"></div>
          </div>
          <div class="field">
            <div class="range-head"><label for="rho">Strength as a residual-norm fraction</label><span id="rhoValue" class="value">0.10</span></div>
            <input id="rho" type="range" min="0" max="0.5" step="0.01" value="0.10">
            <div class="help">At 0.10, the added unit vector has a norm equal to 10% of the normal residual norm at the selected site.</div>
          </div>
          <div class="field">
            <div class="range-head"><label for="length">Maximum response tokens</label><span id="lengthValue" class="value">8</span></div>
            <input id="length" type="range" min="1" max="256" step="1" value="8">
          </div>
        </div>
        <div class="section">
          <h2>How the model variants differ</h2>
          <p class="help">The base option disables every LoRA update. The fixed-site trained models add rank-16 corrections, with alpha 32 and effective scale 2, to the attention and MLP projections in blocks 20 through 39. The original Qwen weights remain frozen. Each adapter contains 32.1 million learned parameters, about 0.23% of the base model.</p>
        </div>
      </aside>

      <div class="content">
        <section id="editor" class="panel editor guided">
          <div class="panel-head">
            <div><h2 id="promptTitle">Prompt</h2><p id="promptExplanation">Loading the experiment prompt.</p></div>
            <div id="tokenMeta" class="meta">0 tokens</div>
          </div>
          <div class="guided-input field"><label for="carrier">Carrier sentence</label><input id="carrier" type="text" value="The copper lantern stood beside the window."></div>
          <div class="freeform-input field"><label for="freeform">Message</label><textarea id="freeform">Describe what you notice about this sentence, then continue with one concise paragraph. The copper lantern stood beside the window.</textarea></div>
          <div class="toolbar" aria-label="Vector painting controls">
            <button class="brush active" data-brush="v1">Paint vector 1</button>
            <button class="brush" data-brush="v2">Paint vector 2</button>
            <button class="brush" data-brush="erase">Erase</button>
            <span class="toolbar-spacer"></span>
            <button id="lastToken" class="quiet">Mark final visible token</button>
            <button id="clear" class="quiet">Clear all</button>
            <button id="retokenize" class="quiet">Refresh tokens</button>
          </div>
          <div id="tokens" class="token-canvas" aria-label="Token-level steering editor"></div>
          <div class="legend"><span><i class="swatch v1"></i>vector 1</span><span><i class="swatch v2"></i>vector 2</span><span id="annotationCount">0 selected positions</span></div>
          <div class="run-row"><button id="run" class="primary">Run model</button><span id="runNote" class="run-note">Prompt edits are re-tokenized automatically before inference.</span></div>
        </section>

        <section class="panel output-panel">
          <div class="panel-head"><div><h2>Model output</h2><p>Candidate logits are taken from the first generated token. Free-form runs also show the highest-logit next tokens.</p></div></div>
          <div id="outputs" class="outputs"><div class="empty">Run the model to see its continuation and next-token logits.</div></div>
        </section>
      </div>
    </div>
  </main>
  <script>
    const state = {
      config: null,
      prompt: "",
      promptSignature: "",
      promptHash: "",
      promptDirty: true,
      refreshSequence: 0,
      refreshTimer: null,
      tokens: [],
      annotations: {},
      candidates: [],
      referenceNorm: null,
      brush: "v1",
      busy: false
    };
    const $ = id => document.getElementById(id);

    async function api(path, options = {}) {
      const response = await fetch(path, { headers: {"Content-Type": "application/json"}, ...options });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || `Request failed: ${response.status}`);
      return data;
    }

    function setStatus(text, ready = false) {
      $("status").classList.toggle("ready", ready);
      $("status").querySelector("span:last-child").textContent = text;
    }

    function pieceLabel(piece) {
      if (piece === " ") return "·";
      return piece.replaceAll(" ", "·").replaceAll("\n", "↵").replaceAll("\t", "⇥");
    }

    function renderTokens() {
      const canvas = $("tokens");
      canvas.replaceChildren();
      for (const token of state.tokens) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "token";
        if (token.control) button.classList.add("control");
        const vector = state.annotations[String(token.index)];
        if (vector) button.classList.add(vector);
        button.textContent = pieceLabel(token.piece) || "∅";
        button.title = `prompt token ${token.index} · id ${token.id}${vector ? ` · ${vector}` : ""}`;
        button.addEventListener("click", () => {
          const key = String(token.index);
          if (state.brush === "erase") delete state.annotations[key];
          else state.annotations[key] = state.brush;
          renderTokens();
        });
        canvas.append(button);
        if (token.piece.includes("\n")) canvas.append(document.createElement("br"));
      }
      const count = Object.keys(state.annotations).length;
      $("annotationCount").textContent = `${count} selected position${count === 1 ? "" : "s"}`;
    }

    function updateVariantDetail() {
      if (!state.config) return;
      const item = state.config.variants.find(value => value.id === $("variant").value);
      $("variantDetail").textContent = item ? item.detail : "";
    }

    function currentPromptSignature() {
      return JSON.stringify({
        preset: $("preset").value,
        carrier: $("carrier").value,
        text: $("freeform").value
      });
    }

    function schedulePromptRefresh() {
      state.promptDirty = true;
      state.refreshSequence += 1;
      clearTimeout(state.refreshTimer);
      setStatus("Prompt changed · updating tokens", false);
      state.refreshTimer = setTimeout(() => refreshPrompt(), 450);
    }

    async function refreshPrompt({ resetLength = false } = {}) {
      if (state.busy) return false;
      const signature = currentPromptSignature();
      const requestSequence = ++state.refreshSequence;
      const preset = $("preset").value;
      $("editor").classList.toggle("guided", preset !== "freeform");
      setStatus("Preparing prompt", false);
      try {
        const data = await api("/api/tokenize", {
          method: "POST",
          body: JSON.stringify({ preset, carrier: $("carrier").value, text: $("freeform").value })
        });
        if (requestSequence !== state.refreshSequence || signature !== currentPromptSignature()) {
          return false;
        }
        state.prompt = data.prompt;
        state.promptSignature = signature;
        state.promptHash = data.prompt_sha256;
        state.promptDirty = false;
        state.tokens = data.tokens;
        state.annotations = data.annotations;
        state.candidates = data.candidate_labels;
        state.referenceNorm = data.reference_norm;
        $("promptTitle").textContent = data.title;
        $("promptExplanation").textContent = data.explanation + (data.expected ? ` The expected answer is ${data.expected}.` : "");
        $("tokenMeta").textContent = `${data.token_count.toLocaleString()} prompt tokens · prompt ${data.prompt_sha256}`;
        if (resetLength) {
          $("length").value = preset === "freeform" ? 96 : 8;
          $("lengthValue").textContent = $("length").value;
        }
        renderTokens();
        setStatus(`${state.config.gpu} · ready`, true);
        return true;
      } catch (error) {
        setStatus("Prompt error", false);
        $("tokens").innerHTML = `<div class="error"></div>`;
        $("tokens").firstElementChild.textContent = error.message;
        return false;
      }
    }

    function renderResult(result) {
      const card = document.createElement("article");
      card.className = "result";
      const head = document.createElement("div");
      head.className = "result-head";
      const name = document.createElement("strong");
      name.textContent = result.variant_name;
      const timing = document.createElement("span");
      timing.textContent = `${result.elapsed_seconds.toFixed(2)}s · ${result.generated_tokens} tokens`;
      head.append(name, timing);
      card.append(head);

      const continuation = document.createElement("div");
      continuation.className = "continuation";
      continuation.textContent = result.continuation || "The model emitted no visible continuation.";
      card.append(continuation);

      if (result.candidate_logits.length) {
        const logits = document.createElement("div");
        logits.className = "logits";
        const title = document.createElement("h3");
        title.textContent = "First-token candidate logits";
        logits.append(title);
        const values = result.candidate_logits.map(row => row.logit);
        const low = Math.min(...values), high = Math.max(...values);
        for (const row of result.candidate_logits) {
          const line = document.createElement("div");
          line.className = "logit-row";
          const label = document.createElement("span"); label.textContent = row.label;
          const track = document.createElement("div"); track.className = "track";
          const fill = document.createElement("div"); fill.className = "fill";
          fill.style.width = `${high === low ? 50 : 10 + 90 * (row.logit - low) / (high - low)}%`;
          track.append(fill);
          const value = document.createElement("span"); value.className = "number"; value.textContent = row.logit.toFixed(3);
          line.append(label, track, value); logits.append(line);
        }
        card.append(logits);
      }

      const details = document.createElement("div");
      details.className = "details";
      const intervention = result.intervention;
      details.textContent = `${result.input_tokens} input tokens · prompt ${result.prompt_sha256} · ${intervention.count} steered position${intervention.count === 1 ? "" : "s"} · block ${intervention.layer} · ρ ${intervention.rho.toFixed(2)} · α ${intervention.alpha.toFixed(3)} · seed ${intervention.seed}`;
      card.append(details);
      return card;
    }

    async function runModel() {
      if (state.busy) return;
      if (state.promptDirty || currentPromptSignature() !== state.promptSignature) {
        clearTimeout(state.refreshTimer);
        const refreshed = await refreshPrompt();
        if (!refreshed || currentPromptSignature() !== state.promptSignature) return;
      }
      state.busy = true;
      $("run").disabled = true;
      $("run").textContent = "Running...";
      $("outputs").innerHTML = '<div class="empty">The model is generating. Comparison runs execute one variant at a time.</div>';
      setStatus("Running inference", false);
      try {
        let variants = [$("variant").value];
        if ($("compare").checked) {
          if (variants[0] === "base") variants.push("trained_20260820");
          else variants.unshift("base");
        }
        variants = [...new Set(variants)];
        const data = await api("/api/generate", {
          method: "POST",
          body: JSON.stringify({
            prompt: state.prompt,
            annotations: state.annotations,
            candidate_labels: state.candidates,
            reference_norm: state.referenceNorm,
            variants,
            layer: Number($("layer").value),
            rho: Number($("rho").value),
            seed: Number($("seed").value),
            max_new_tokens: Number($("length").value)
          })
        });
        $("outputs").replaceChildren(...data.results.map(renderResult));
        setStatus(`${state.config.gpu} · ready`, true);
      } catch (error) {
        const box = document.createElement("div"); box.className = "error"; box.textContent = error.message;
        $("outputs").replaceChildren(box);
        setStatus("Inference error", false);
      } finally {
        state.busy = false;
        $("run").disabled = false;
        $("run").textContent = "Run model";
      }
    }

    async function initialize() {
      try {
        state.config = await api("/api/status");
        for (const item of state.config.presets) {
          const option = document.createElement("option"); option.value = item.id; option.textContent = item.name; $("preset").append(option);
        }
        for (const item of state.config.variants) {
          const option = document.createElement("option"); option.value = item.id; option.textContent = item.name; $("variant").append(option);
        }
        $("preset").value = "label_v2";
        $("variant").value = "trained_20260820";
        updateVariantDetail();
        setStatus(`${state.config.gpu} · ready`, true);
        await refreshPrompt({ resetLength: true });
      } catch (error) {
        setStatus("Could not reach model", false);
        $("outputs").innerHTML = '<div class="error"></div>';
        $("outputs").firstElementChild.textContent = error.message;
      }
    }

    document.querySelectorAll(".brush").forEach(button => button.addEventListener("click", () => {
      state.brush = button.dataset.brush;
      document.querySelectorAll(".brush").forEach(value => value.classList.toggle("active", value === button));
    }));
    $("preset").addEventListener("change", () => refreshPrompt({ resetLength: true }));
    $("carrier").addEventListener("input", schedulePromptRefresh);
    $("freeform").addEventListener("input", schedulePromptRefresh);
    $("variant").addEventListener("change", updateVariantDetail);
    $("retokenize").addEventListener("click", refreshPrompt);
    $("clear").addEventListener("click", () => { state.annotations = {}; renderTokens(); });
    $("lastToken").addEventListener("click", () => {
      const visible = state.tokens.filter(token => !token.control && token.piece.trim());
      if (visible.length) {
        const key = String(visible.at(-1).index);
        if (state.brush === "erase") delete state.annotations[key];
        else state.annotations[key] = state.brush;
      }
      renderTokens();
    });
    $("rho").addEventListener("input", event => $("rhoValue").textContent = Number(event.target.value).toFixed(2));
    $("length").addEventListener("input", event => $("lengthValue").textContent = event.target.value);
    $("run").addEventListener("click", runModel);
    initialize();
  </script>
</body>
</html>'''


class StudioHandler(BaseHTTPRequestHandler):
    engine: ModelEngine | MockEngine

    def _json(self, value: Any, status: int = 200) -> None:
        data = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        if self.path in {"/", "/index.html"}:
            data = HTML.encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path.rstrip("/") == "/api/status":
            self._json(self.engine.status())
            return
        self._json({"error": "Not found"}, status=404)

    def do_POST(self) -> None:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 8_000_000:
                raise ValueError("Request body must be between 1 byte and 8 MB")
            payload = json.loads(self.rfile.read(length))
            if self.path.rstrip("/") == "/api/tokenize":
                self._json(self.engine.tokenize(payload))
                return
            if self.path.rstrip("/") == "/api/generate":
                self._json(self.engine.generate(payload))
                return
            self._json({"error": "Not found"}, status=404)
        except (ValueError, KeyError, RuntimeError) as exc:
            self._json({"error": str(exc)}, status=400)
        except Exception as exc:
            traceback.print_exc()
            self._json({"error": f"Unexpected server error: {exc}"}, status=500)

    def log_message(self, format_string: str, *args: Any) -> None:
        print(f"http {self.address_string()} {format_string % args}", flush=True)


def self_test(engine: ModelEngine | MockEngine) -> None:
    tokenized = engine.tokenize({
        "preset": "label_v2",
        "carrier": DEFAULT_CARRIER,
        "text": DEFAULT_FREEFORM,
    })
    result = engine.generate({
        "prompt": tokenized["prompt"],
        "annotations": tokenized["annotations"],
        "candidate_labels": tokenized["candidate_labels"],
        "reference_norm": tokenized["reference_norm"],
        "variants": ["base", "trained_20260820"],
        "layer": 20,
        "rho": 0.1,
        "seed": 20260820,
        "max_new_tokens": 2,
    })
    if len(result["results"]) != 2:
        raise RuntimeError("Expected base and trained self-test results")
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--mock", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.mock:
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is required unless --mock is used")
        if not torch.cuda.is_bf16_supported():
            raise RuntimeError("The selected GPU does not report BF16 support")
    engine: ModelEngine | MockEngine = MockEngine() if args.mock else ModelEngine()
    if args.self_test:
        self_test(engine)
        return 0
    StudioHandler.engine = engine
    server = ThreadingHTTPServer((args.host, args.port), StudioHandler)
    print(f"Residual Marker Studio ready at http://{args.host}:{args.port}/", flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
