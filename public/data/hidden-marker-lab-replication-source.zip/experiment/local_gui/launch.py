"""Launch the GPU-backed Residual Marker Studio through a private SSH tunnel."""

from __future__ import annotations

import atexit
import html
import json
import os
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import webbrowser
from dataclasses import dataclass
from pathlib import Path


ATHENA_HOST = "agastyas@athena01.ig32s.ruhr-uni-bochum.de"
_ACTIVE_SESSION: "StudioSession | None" = None


def _free_local_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _remote_port() -> int:
    # The range is intentionally high and derived from the local process and time.
    # The server will fail clearly if a rare collision occurs.
    return 18000 + ((os.getpid() + int(time.time())) % 12000)


def _log_tail(path: Path, lines: int = 40) -> str:
    if not path.exists():
        return "No server log was written."
    return "\n".join(path.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:])


@dataclass
class StudioSession:
    """Processes and URL for one private Athena GUI session."""

    url: str
    server_process: subprocess.Popen
    tunnel_process: subprocess.Popen
    log_path: Path
    remote_pid: int

    def stop(self) -> None:
        if self.remote_pid > 0:
            subprocess.run(
                ["ssh", "-o", "BatchMode=yes", ATHENA_HOST, "kill", str(self.remote_pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15,
                check=False,
            )
        for process in (self.server_process, self.tunnel_process):
            if process.poll() is None:
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.terminate()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=3)

    def _repr_html_(self) -> str:
        safe_url = html.escape(self.url, quote=True)
        safe_log = html.escape(str(self.log_path))
        return (
            '<div style="border:1px solid #ded5c8;border-radius:8px;padding:14px 16px;'
            'background:#fffdf9;color:#2c2416;font-family:Georgia,serif">'
            '<div style="font-weight:600;margin-bottom:5px">Residual Marker Studio is running</div>'
            f'<a href="{safe_url}" target="_blank" style="color:#3d6648">Open the local interface</a>'
            f'<div style="font-size:12px;color:#736453;margin-top:7px">Log: {safe_log}</div>'
            '</div>'
        )


def launch_athena_studio(
    gpu: str | int = "auto",
    *,
    timeout_seconds: int = 900,
    open_browser: bool = False,
) -> StudioSession:
    """Start the model server with gpurun and expose it only on localhost."""

    global _ACTIVE_SESSION
    if _ACTIVE_SESSION is not None:
        if _ACTIVE_SESSION.server_process.poll() is None and _ACTIVE_SESSION.tunnel_process.poll() is None:
            return _ACTIVE_SESSION
        _ACTIVE_SESSION.stop()
        _ACTIVE_SESSION = None

    script = Path(__file__).with_name("athena_app.py").resolve()
    if not script.exists():
        raise FileNotFoundError(f"Missing Athena application: {script}")

    gpurun = shutil.which("gpurun") or str(Path.home() / ".local" / "bin" / "gpurun")
    if not Path(gpurun).exists():
        raise FileNotFoundError("gpurun was not found. Expected ~/.local/bin/gpurun")

    local_port = _free_local_port()
    remote_port = _remote_port()
    log_path = Path(tempfile.gettempdir()) / f"residual-marker-studio-{int(time.time())}.log"
    log_handle = log_path.open("w", encoding="utf-8")

    environment = os.environ.copy()
    environment["GPU"] = str(gpu)
    print(f"Starting Residual Marker Studio on Athena GPU {gpu}. Model loading can take several minutes.")
    server = subprocess.Popen(
        [gpurun, str(script), "--host", "127.0.0.1", "--port", str(remote_port)],
        stdout=log_handle,
        stderr=subprocess.STDOUT,
        env=environment,
        text=True,
    )

    tunnel = subprocess.Popen(
        [
            "ssh",
            "-o", "BatchMode=yes",
            "-o", "ExitOnForwardFailure=yes",
            "-o", "ServerAliveInterval=30",
            "-N",
            "-L", f"127.0.0.1:{local_port}:127.0.0.1:{remote_port}",
            ATHENA_HOST,
        ],
        stdout=subprocess.DEVNULL,
        stderr=log_handle,
        text=True,
    )
    log_handle.close()

    url = f"http://127.0.0.1:{local_port}/"
    deadline = time.monotonic() + timeout_seconds
    last_progress = 0.0
    remote_pid = 0
    try:
        while time.monotonic() < deadline:
            if server.poll() is not None:
                raise RuntimeError(
                    f"The Athena server stopped before becoming ready.\n\n{_log_tail(log_path)}"
                )
            if tunnel.poll() is not None:
                raise RuntimeError(
                    f"The private SSH tunnel stopped before becoming ready.\n\n{_log_tail(log_path)}"
                )
            try:
                with urllib.request.urlopen(url + "api/status", timeout=2) as response:
                    if response.status == 200:
                        status = json.load(response)
                        remote_pid = int(status["server_pid"])
                        break
            except (urllib.error.URLError, TimeoutError, ConnectionError):
                pass

            now = time.monotonic()
            if now - last_progress >= 20:
                print("Still loading the model on Athena...")
                last_progress = now
            time.sleep(2)
        else:
            raise TimeoutError(
                f"The Athena server did not become ready within {timeout_seconds} seconds.\n\n"
                f"{_log_tail(log_path)}"
            )
    except Exception:
        for process in (tunnel, server):
            if process.poll() is None:
                process.terminate()
        raise

    session = StudioSession(url, server, tunnel, log_path, remote_pid)
    _ACTIVE_SESSION = session
    atexit.register(session.stop)
    print(f"Ready: {url}")
    if open_browser:
        webbrowser.open(url)
    return session
