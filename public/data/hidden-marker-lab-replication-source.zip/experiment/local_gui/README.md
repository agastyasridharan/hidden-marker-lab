# Residual Marker Studio

This is a separate local interface for running Qwen3-14B on Athena. It is not a
route in the published results dashboard. The browser connects to `localhost`,
and an SSH tunnel carries requests to a single GPU process on Athena.

The interface supports:

- the original label-choice and binary dax prompts;
- arbitrary free-form user text;
- token-level selection of every intervention site;
- independently sampled vector 1 and vector 2 directions;
- configurable direction seed, transformer block, and relative strength;
- deterministic generation and first-token candidate logits;
- the base Qwen3-14B model, three fixed-site LoRA replications, and the
  cross-layer LoRA adapter;
- side-by-side base and trained runs with identical prompts and vectors.

Changing the carrier sentence or free-form message automatically rebuilds the
tokenized prompt before inference. The token panel and every result card show a
12-character SHA-256 prompt fingerprint. If two result cards show different
fingerprints, they were scored from different rendered prompts; if the
fingerprints match, the visible prompt supplied to the model was identical.

## Launch from the replication notebook

Near the top of `notebooks/hidden_marker_lab_replication.ipynb`, first run the
two support-preparation cells. They extract the interface from the notebook
itself, so this works even when the `.ipynb` was downloaded without the rest of
the repository. Then set `LAUNCH_ATHENA_STUDIO = True` and run the launch cell.
It calls:

```python
from experiment.local_gui import launch_athena_studio

studio = launch_athena_studio(gpu="auto")
studio
```

The returned link is local to the Mac. Stop the session with `studio.stop()`.
Closing the notebook kernel also closes the tunnel and the associated `gpurun`
process.

## Direct launch

```python
from experiment.local_gui import launch_athena_studio

studio = launch_athena_studio(gpu="auto", open_browser=True)
```

The launcher uploads only `athena_app.py`, which is self-contained. The server
uses the shared Hugging Face cache and the existing adapter checkpoints under
`/data/agastyas/hidden-marker-ift/`. It never writes model weights to Athena's
small home volume.

## Tests

The local mock test does not load a model:

```bash
python3 experiment/local_gui/athena_app.py --mock --self-test
```

The real GPU smoke test uses the same server code and checks both base and
trained inference:

```bash
GPU=auto gpurun experiment/local_gui/athena_app.py --self-test
```
