#!/usr/bin/env python3
"""Train and evaluate in-context matching of arbitrary residual perturbations.

The runner is self-contained because Athena's ``gpurun`` wrapper uploads one
Python file. Training data are generated online: every base episode receives a
fresh orthonormal vector pair, random nonce labels, random demonstration order,
random option order, and both possible test directions.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import random
import statistics
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer


MODEL_ID = "Qwen/Qwen3-14B"
DEFAULT_LAYER = 20
DEFAULT_RHO = 0.1

SYSTEM_PROMPT = (
    "During this conversation, arbitrary hidden markers may be injected into "
    "your internal activations while you read sentences. Their names are "
    "arbitrary and are defined only by the examples. Answer the final question "
    "with only the option letter."
)

TRAIN_LABELS = [
    "dax", "wug", "zorp", "kiki", "fep", "toma", "blick", "nust",
    "vash", "pim", "lorn", "grel", "sivet", "marn", "tulver", "kob",
    "zan", "plim", "drave", "quol", "fint", "besk", "naro", "yem",
    "cavor", "rusk", "tep", "jond", "miv", "sarn", "dovel", "pran",
    "lutik", "gamb", "hesp", "wern", "vop", "cresh", "nib", "talgo",
    "sulik", "bram", "yorp", "kest", "falo", "dren", "pask", "murel",
]

EVAL_LABELS = [
    "abex", "cudra", "elpin", "gavor", "hux", "irven", "jaska", "lomit",
    "mevro", "nupil", "oska", "peld", "rivan", "sotel", "udra", "velk",
    "wempo", "xarin", "yulda", "zevik", "breno", "clov", "driso", "etvan",
]

SUBJECTS = [
    "copper lantern", "linen map", "narrow footbridge", "blue teacup",
    "cedar chest", "paper kite", "brass key", "small fern", "morning ferry",
    "wool scarf", "glass marble", "white heron", "old clock", "wooden spoon",
    "garden gate", "silver thimble", "empty canoe", "folded letter",
    "distant lighthouse", "green bottle", "striped blanket", "clay whistle",
    "evening train", "red ribbon", "stone fountain", "yellow leaf",
    "canvas satchel", "quiet sparrow", "iron bell", "shallow basket",
    "moonlit path", "ceramic vase", "faded curtain", "round pebble",
    "wooden ladder", "cotton glove", "painted sign", "black umbrella",
    "marble step", "woven mat", "tin cup", "pale shell", "orchard path",
    "leather journal", "little windmill", "crystal bead", "weathered rope",
    "dry twig", "quiet library", "bronze coin", "narrow chimney",
    "striped shell", "willow branch", "square envelope", "mossy steps",
    "tiny feather", "bakery window", "porcelain button", "oak drawer",
    "grey rabbit", "narrow bookshelf", "copper pan", "wooden compass",
]

PREDICATES = [
    "stood beside the window", "rested beneath the compass", "crossed the quiet stream",
    "waited near the kettle", "remained under the staircase", "drifted above the meadow",
    "lay beside the notebook", "grew between the stones", "approached the eastern pier",
    "hung behind the door", "rolled across the table", "watched from the riverbank",
    "chimed before the rain", "rested inside the bowl", "opened toward the orchard",
    "gleamed on the shelf", "floated beside the reeds", "waited under the book",
    "marked the rocky coast", "stood near the basin", "covered the wooden bench",
    "sat beside the candle", "passed beyond the hill", "circled the parcel",
    "stood within the courtyard", "landed on the railing", "leaned against the chair",
    "perched above the doorway", "hung inside the tower", "held three apples",
    "curved around the pond", "rested on the mantel",
]

# Final evaluation carriers use a lexically disjoint pool. These strings are
# never sampled by the training objectives, so success cannot depend on
# memorizing the finite training carrier vocabulary.
EVAL_SUBJECTS = [
    "amber telescope", "velvet pouch", "granite sundial", "indigo pennant",
    "maple violin", "pewter goblet", "bamboo screen", "coral brooch",
    "ivory domino", "scarlet bonnet", "quartz prism", "walnut easel",
    "satin cushion", "alabaster figurine", "lacquered tray", "hempen hammock",
    "cobalt pitcher", "platinum locket", "rattan stool", "silken banner",
    "charcoal sketch", "opal pendant", "birchwood flute", "crimson parasol",
    "jade astrolabe", "velour cap", "granite mortar", "amber hourglass",
    "cork diorama", "mahogany harpsichord", "faience censer", "tartan shawl",
]

EVAL_PREDICATES = [
    "waited beyond the greenhouse", "rested beside the observatory",
    "stood beneath the awning", "drifted past the conservatory",
    "remained near the turnstile", "leaned against the balustrade",
    "gleamed inside the alcove", "settled above the vestibule",
    "paused beside the pergola", "lay underneath the trellis",
    "hovered over the cloister", "stood behind the proscenium",
    "rested within the pavilion", "waited beside the colonnade",
    "moved beyond the rotunda", "remained under the portico",
    "sat near the cupola", "hung above the mezzanine",
    "stood within the belvedere", "rested beside the parapet",
    "waited behind the apothecary", "lay beneath the planetarium",
    "paused outside the refectory", "remained near the aqueduct",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
        temp = Path(handle.name)
    os.replace(temp, path)


def atomic_torch_save(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("wb", dir=path.parent, delete=False, suffix=".pt") as handle:
        temp = Path(handle.name)
    torch.save(value, temp)
    os.replace(temp, path)


def stable_seed(seed: int, namespace: str, index: int) -> int:
    digest = hashlib.sha256(f"{seed}:{namespace}:{index}".encode()).digest()
    return int.from_bytes(digest[:8], "little") & 0x7FFF_FFFF_FFFF_FFFF


def deterministic_random(seed: int, namespace: str, index: int) -> random.Random:
    return random.Random(stable_seed(seed, namespace, index))


def make_carrier(seed: int, index: int, split: str) -> str:
    rng_namespace = "eval" if split == "eval-train-pool" else split
    rng = deterministic_random(seed, f"carrier-{rng_namespace}", index)
    subjects = EVAL_SUBJECTS if split == "eval" else SUBJECTS
    predicates = EVAL_PREDICATES if split == "eval" else PREDICATES
    subject = subjects[rng.randrange(len(subjects))]
    predicate = predicates[rng.randrange(len(predicates))]
    article = "An" if subject[0].lower() in "aeiou" else "A"
    if rng.random() < 0.5:
        article = "The"
    return f"{article} {subject} {predicate}."


def _fwht(values: torch.Tensor) -> torch.Tensor:
    """Apply an orthonormal Walsh-Hadamard transform to 1024-row blocks."""
    if values.shape[0] % 1024:
        raise ValueError("hidden size must be divisible by 1024 for dense subspace sampling")
    transformed = values.reshape(-1, 1024, values.shape[1]).clone()
    width = 1
    while width < 1024:
        grouped = transformed.reshape(transformed.shape[0], -1, width * 2, transformed.shape[-1])
        left = grouped[:, :, :width].clone()
        right = grouped[:, :, width:].clone()
        grouped[:, :, :width] = left + right
        grouped[:, :, width:] = left - right
        transformed = grouped.reshape_as(transformed)
        width *= 2
    return transformed.reshape_as(values) / math.sqrt(1024)


def _dense_subspace_transform(values: torch.Tensor, seed: int) -> torch.Tensor:
    """Rotate coefficient vectors with a deterministic exact orthogonal map."""
    generator = torch.Generator(device="cpu")
    generator.manual_seed(stable_seed(seed, "subspace-transform", values.shape[0]))
    signs = torch.randint(0, 2, (values.shape[0], 1), generator=generator).mul_(2).sub_(1)
    permutation = torch.randperm(values.shape[0], generator=generator)
    return (_fwht(values) * signs.to(values.dtype))[permutation]


def sample_pair(
    hidden_size: int,
    seed: int,
    family: str = "gaussian",
    direction_mode: str = "full",
    subspace_seed: int = 0,
) -> tuple[torch.Tensor, torch.Tensor]:
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    if direction_mode not in {"full", "subspace-train", "subspace-holdout"}:
        raise ValueError(f"unknown direction mode: {direction_mode}")
    support_indices: torch.Tensor | None = None
    sampling_size = hidden_size
    if direction_mode != "full":
        support_generator = torch.Generator(device="cpu")
        support_generator.manual_seed(stable_seed(subspace_seed, "subspace-partition", hidden_size))
        partition = torch.randperm(hidden_size, generator=support_generator)
        split = hidden_size // 2
        support_indices = partition[:split] if direction_mode == "subspace-train" else partition[split:]
        sampling_size = int(support_indices.numel())
    if family == "gaussian":
        matrix = torch.randn(sampling_size, 2, generator=generator, dtype=torch.float32)
    elif family == "rademacher":
        matrix = torch.randint(0, 2, (sampling_size, 2), generator=generator, dtype=torch.int64)
        matrix = matrix.to(torch.float32).mul_(2).sub_(1)
    elif family == "sparse":
        matrix = torch.zeros(sampling_size, 2, dtype=torch.float32)
        support = max(8, sampling_size // 20)
        for column in range(2):
            indices = torch.randperm(sampling_size, generator=generator)[:support]
            matrix[indices, column] = torch.randn(support, generator=generator)
    else:
        raise ValueError(f"unknown vector family: {family}")
    q, _ = torch.linalg.qr(matrix, mode="reduced")
    signs = torch.randint(0, 2, (2,), generator=generator, dtype=torch.int64).mul(2).sub(1)
    q = q * signs.to(torch.float32)
    if bool(torch.randint(0, 2, (1,), generator=generator).item()):
        q = q[:, [1, 0]]
    if support_indices is not None:
        coefficients = torch.zeros(hidden_size, 2, dtype=torch.float32)
        coefficients[support_indices] = q
        q = _dense_subspace_transform(coefficients, subspace_seed)
    return q[:, 0].contiguous(), q[:, 1].contiguous()


class LoRALinear(nn.Module):
    def __init__(self, base: nn.Linear, rank: int, alpha: float) -> None:
        super().__init__()
        self.base = base
        self.rank = rank
        self.scale = alpha / rank
        self.lora_A = nn.Parameter(torch.empty(rank, base.in_features, device=base.weight.device))
        self.lora_B = nn.Parameter(torch.zeros(base.out_features, rank, device=base.weight.device))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        self.lora_A.data = self.lora_A.data.float()
        self.lora_B.data = self.lora_B.data.float()

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        base_output = self.base(inputs)
        delta = F.linear(F.linear(inputs.float(), self.lora_A), self.lora_B)
        return base_output + delta.to(base_output.dtype) * self.scale


def transformer_layers(model: nn.Module) -> Sequence[nn.Module]:
    layers = getattr(getattr(model, "model", None), "layers", None)
    if layers is None:
        raise RuntimeError("could not locate transformer layers")
    return layers


TARGET_PROJECTIONS = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")


def attach_lora(model: nn.Module, start_layer: int, rank: int, alpha: float) -> list[str]:
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    replaced: list[str] = []
    layers = transformer_layers(model)
    for layer_index in range(start_layer, len(layers)):
        layer = layers[layer_index]
        for prefix in ("self_attn", "mlp"):
            parent = getattr(layer, prefix)
            for name in TARGET_PROJECTIONS:
                if not hasattr(parent, name):
                    continue
                module = getattr(parent, name)
                if not isinstance(module, nn.Linear):
                    continue
                setattr(parent, name, LoRALinear(module, rank, alpha))
                replaced.append(f"model.layers.{layer_index}.{prefix}.{name}")
    if not replaced:
        raise RuntimeError("no linear projections were replaced with LoRA")
    return replaced


def adapter_state(model: nn.Module) -> dict[str, torch.Tensor]:
    return {
        name: parameter.detach().cpu()
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    }


def load_adapter_state(model: nn.Module, state: dict[str, torch.Tensor]) -> None:
    parameters = dict(model.named_parameters())
    missing = set(state) - set(parameters)
    if missing:
        raise RuntimeError(f"adapter parameters missing from model: {sorted(missing)[:3]}")
    with torch.no_grad():
        for name, value in state.items():
            parameters[name].copy_(value.to(parameters[name].device, parameters[name].dtype))


@dataclass
class InjectionRow:
    positions: list[int]
    vectors: list[torch.Tensor]
    rho: float


class InterventionController:
    def __init__(self) -> None:
        self.plan: list[InjectionRow] | None = None
        self.last_scales: list[float] = []

    def hook(self, _module: nn.Module, args: tuple[Any, ...]) -> tuple[Any, ...]:
        if self.plan is None:
            return args
        hidden = args[0]
        if len(self.plan) != hidden.shape[0]:
            raise RuntimeError("injection plan batch size mismatch")
        modified = hidden.clone()
        scales: list[float] = []
        for row_index, row in enumerate(self.plan):
            if not row.positions:
                scales.append(0.0)
                continue
            norms = torch.stack([
                hidden[row_index, position].detach().float().norm()
                for position in row.positions
            ])
            alpha = float((norms.median() * row.rho).item())
            scales.append(alpha)
            for position, vector in zip(row.positions, row.vectors):
                delta = vector.to(device=hidden.device, dtype=hidden.dtype) * alpha
                modified[row_index, position] = modified[row_index, position] + delta
        self.last_scales = scales
        return (modified, *args[1:])


def render_chat(tokenizer: Any, messages: list[dict[str, str]]) -> str:
    rendered = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    return rendered + "The answer is:"


def period_positions(tokenizer: Any, prompt: str, sentences: Sequence[str]) -> list[int]:
    encoded = tokenizer(prompt, add_special_tokens=False, return_offsets_mapping=True)
    offsets = encoded["offset_mapping"]
    positions: list[int] = []
    cursor = 0
    for sentence in sentences:
        start = prompt.find(sentence, cursor)
        if start < 0:
            raise RuntimeError(f"carrier not found in rendered prompt: {sentence!r}")
        period = start + sentence.rfind(".")
        token_position = next(
            (index for index, (left, right) in enumerate(offsets) if left <= period < right),
            None,
        )
        if token_position is None:
            raise RuntimeError("final period was not covered by a token offset")
        positions.append(int(token_position))
        cursor = start + len(sentence)
    return positions


def candidate_tokens(tokenizer: Any, letters: str) -> dict[str, int]:
    for prefix in (" ", ""):
        result = {letter: tokenizer.encode(prefix + letter, add_special_tokens=False) for letter in letters}
        if all(len(ids) == 1 for ids in result.values()) and len({ids[0] for ids in result.values()}) == len(letters):
            return {letter: int(ids[0]) for letter, ids in result.items()}
    raise RuntimeError(f"candidate letters are not distinct single tokens: {letters}")


@dataclass
class Example:
    prompt: str
    positions: list[int]
    vectors: list[torch.Tensor]
    rho: float
    candidates: str
    correct_index: int
    metadata: dict[str, Any]


def choose_labels(seed: int, episode_id: int, split: str) -> tuple[str, str]:
    pool = EVAL_LABELS if split == "eval" else TRAIN_LABELS
    rng = deterministic_random(seed, f"labels-{split}", episode_id)
    first, second = rng.sample(pool, 2)
    return first, second


def label_example(
    tokenizer: Any,
    seed: int,
    episode_id: int,
    vector_pair: tuple[torch.Tensor, torch.Tensor],
    test_vector: int,
    rho: float,
    split: str,
    mapping_swap: bool,
    demo_reverse: bool,
    option_reverse: bool,
    carrier_mode: str,
    control: str = "primary",
    carrier_split: str | None = None,
) -> Example:
    labels = list(choose_labels(seed, episode_id, split))
    if mapping_swap:
        labels.reverse()
    demo_order = [1, 0] if demo_reverse else [0, 1]
    carrier_base = episode_id * 5
    effective_carrier_split = carrier_split or split
    if carrier_mode == "same":
        carriers = [make_carrier(seed, carrier_base, effective_carrier_split)] * 3
    elif carrier_mode == "different":
        carriers = [
            make_carrier(seed, carrier_base + offset, effective_carrier_split)
            for offset in range(3)
        ]
    else:
        raise ValueError(f"unknown carrier mode: {carrier_mode}")

    messages: list[dict[str, str]] = [{"role": "system", "content": SYSTEM_PROMPT}]
    shown_sentences: list[str] = []
    shown_vectors: list[torch.Tensor] = []
    for demonstration_index, vector_index in enumerate(demo_order, start=1):
        sentence = carriers[demonstration_index - 1]
        shown_sentences.append(sentence)
        shown_vectors.append(vector_pair[vector_index])
        messages.extend([
            {
                "role": "user",
                "content": f"Example {demonstration_index}. Read the following sentence carefully:\n{sentence}",
            },
            {
                "role": "assistant",
                "content": f"The hidden marker in that sentence was {labels[vector_index]}.",
            },
        ])

    option_labels = [labels[0], labels[1]]
    if option_reverse:
        option_labels.reverse()
    correct_label = labels[test_vector]
    correct_index = option_labels.index(correct_label)
    test_sentence = carriers[2]
    shown_sentences.append(test_sentence)
    messages.append({
        "role": "user",
        "content": (
            f"Test. Read the following sentence carefully:\n{test_sentence}\n\n"
            f"Which hidden marker occurred?\nA) {option_labels[0]}\nB) {option_labels[1]}"
        ),
    })
    prompt = render_chat(tokenizer, messages)
    positions = period_positions(tokenizer, prompt, shown_sentences)
    injected_vectors = list(shown_vectors)
    injected_positions = list(positions[:2])
    if control == "primary":
        injected_positions.append(positions[2])
        injected_vectors.append(vector_pair[test_vector])
    elif control == "no-test":
        pass
    elif control == "sign-flip":
        injected_positions.append(positions[2])
        injected_vectors.append(-vector_pair[test_vector])
    elif control == "orthogonal-test":
        third, _ = sample_pair(vector_pair[0].numel(), stable_seed(seed, "third", episode_id), "gaussian")
        third = third - torch.dot(third, vector_pair[0]) * vector_pair[0]
        third = third - torch.dot(third, vector_pair[1]) * vector_pair[1]
        third = third / third.norm()
        injected_positions.append(positions[2])
        injected_vectors.append(third)
    else:
        raise ValueError(f"unknown control: {control}")

    return Example(
        prompt=prompt,
        positions=injected_positions,
        vectors=injected_vectors,
        rho=rho,
        candidates="AB",
        correct_index=correct_index,
        metadata={
            "episode_id": episode_id,
            "test_vector": f"v{test_vector + 1}",
            "correct_option": "AB"[correct_index],
            "correct_label": correct_label,
            "labels_by_vector": {"v1": labels[0], "v2": labels[1]},
            "mapping_swap": mapping_swap,
            "demo_reverse": demo_reverse,
            "option_reverse": option_reverse,
            "carrier_mode": carrier_mode,
            "sentence": test_sentence,
            "control": control,
        },
    )


def same_different_example(
    tokenizer: Any,
    seed: int,
    episode_id: int,
    rho: float,
    direction_mode: str = "full",
    subspace_seed: int = 0,
) -> Example:
    rng = deterministic_random(seed, "same-different", episode_id)
    v1, v2 = sample_pair(
        5120, stable_seed(seed, "sd-vector", episode_id), "gaussian",
        direction_mode, subspace_seed,
    )
    is_same = bool(episode_id % 2)
    option_reverse = bool(rng.randrange(2))
    options = ["same", "different"]
    if option_reverse:
        options.reverse()
    correct_index = options.index("same" if is_same else "different")
    sentences = [make_carrier(seed, episode_id * 2 + offset, "train") for offset in range(2)]
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Sentence 1: {sentences[0]}\nSentence 2: {sentences[1]}\n\n"
                "Did the same arbitrary hidden marker occur in both sentences?\n"
                f"A) {options[0]}\nB) {options[1]}"
            ),
        },
    ]
    prompt = render_chat(tokenizer, messages)
    positions = period_positions(tokenizer, prompt, sentences)
    return Example(
        prompt, positions, [v1, v1 if is_same else v2], rho, "AB", correct_index,
        {"objective": "same-different", "same": is_same, "option_reverse": option_reverse},
    )


def localization_example(
    tokenizer: Any,
    seed: int,
    episode_id: int,
    rho: float,
    direction_mode: str = "full",
    subspace_seed: int = 0,
) -> Example:
    target = episode_id % 4
    sentences = [make_carrier(seed, episode_id * 4 + offset, "train") for offset in range(4)]
    vector, _ = sample_pair(
        5120, stable_seed(seed, "loc-vector", episode_id), "gaussian",
        direction_mode, subspace_seed,
    )
    lines = "\n".join(f"Sentence {index + 1}: {sentence}" for index, sentence in enumerate(sentences))
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"{lines}\n\nWhich sentence contained the hidden marker?\n"
                "A) Sentence 1\nB) Sentence 2\nC) Sentence 3\nD) Sentence 4"
            ),
        },
    ]
    prompt = render_chat(tokenizer, messages)
    all_positions = period_positions(tokenizer, prompt, sentences)
    return Example(
        prompt, [all_positions[target]], [vector], rho, "ABCD", target,
        {"objective": "localization", "target": target + 1},
    )


def batch_examples(tokenizer: Any, examples: Sequence[Example], device: torch.device) -> tuple[dict[str, torch.Tensor], list[InjectionRow], torch.Tensor, list[int]]:
    if len({example.candidates for example in examples}) != 1:
        raise RuntimeError("all examples in a batch must share candidates")
    encoded = tokenizer(
        [example.prompt for example in examples],
        add_special_tokens=False,
        padding=True,
        return_tensors="pt",
    ).to(device)
    plans = [InjectionRow(example.positions, example.vectors, example.rho) for example in examples]
    targets = torch.tensor([example.correct_index for example in examples], device=device)
    token_map = candidate_tokens(tokenizer, examples[0].candidates)
    candidate_ids = [token_map[letter] for letter in examples[0].candidates]
    return encoded, plans, targets, candidate_ids


def candidate_logits(model: nn.Module, encoded: dict[str, torch.Tensor], candidate_ids: Sequence[int]) -> torch.Tensor:
    outputs = model(**encoded, use_cache=False, return_dict=True)
    final_positions = encoded["attention_mask"].sum(dim=1) - 1
    rows = torch.arange(encoded["input_ids"].shape[0], device=encoded["input_ids"].device)
    logits = outputs.logits[rows, final_positions]
    return logits[:, list(candidate_ids)].float()


def vector_fingerprint(vector: torch.Tensor) -> str:
    return hashlib.sha256(vector.numpy().tobytes()).hexdigest()[:16]


def wilson(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total == 0:
        return 0.0, 1.0
    p = successes / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    radius = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return center - radius, center + radius


def summarize_trials(trials: Sequence[dict[str, Any]]) -> dict[str, Any]:
    correct = sum(bool(trial["correct"]) for trial in trials)
    margins = [float(trial["margin"]) for trial in trials]
    low, high = wilson(correct, len(trials))
    return {
        "n_trials": len(trials),
        "n_correct": correct,
        "accuracy": correct / len(trials) if trials else 0.0,
        "ci_95_wilson_descriptive": [low, high],
        "mean_margin": statistics.fmean(margins) if margins else 0.0,
        "median_margin": statistics.median(margins) if margins else 0.0,
        "prediction_counts": {
            "A": sum(trial["prediction"] == "A" for trial in trials),
            "B": sum(trial["prediction"] == "B" for trial in trials),
        },
    }


def primary_dependence_metrics(trials: Sequence[dict[str, Any]], seed: int) -> dict[str, Any]:
    by_episode: dict[int, list[dict[str, Any]]] = {}
    by_pair: dict[tuple[int, bool, bool, bool], list[dict[str, Any]]] = {}
    for trial in trials:
        episode_id = int(trial["episode_id"])
        by_episode.setdefault(episode_id, []).append(trial)
        key = (
            episode_id,
            bool(trial["mapping_swap"]),
            bool(trial["demo_reverse"]),
            bool(trial["option_reverse"]),
        )
        by_pair.setdefault(key, []).append(trial)
    episode_scores = np.array([
        statistics.fmean(float(row["correct"]) for row in rows)
        for rows in by_episode.values()
    ], dtype=np.float64)
    generator = np.random.default_rng(stable_seed(seed, "cluster-bootstrap", len(trials)))
    bootstrap = np.empty(10_000, dtype=np.float64)
    for index in range(len(bootstrap)):
        sample = generator.integers(0, len(episode_scores), size=len(episode_scores))
        bootstrap[index] = episode_scores[sample].mean()
    complete_orbits = []
    for episode_id in by_episode:
        for vector_name in ("v1", "v2"):
            rows = [row for row in by_episode[episode_id] if row["test_vector"] == vector_name]
            complete_orbits.append(all(bool(row["correct"]) for row in rows))
    return {
        "cluster_bootstrap_ci_95": [
            float(np.quantile(bootstrap, 0.025)),
            float(np.quantile(bootstrap, 0.975)),
        ],
        "complete_counterfactual_orbit_success_rate": statistics.fmean(complete_orbits),
        "n_counterfactual_orbits": len(complete_orbits),
        "paired_transform_success_rate": statistics.fmean(
            all(bool(row["correct"]) for row in rows) for rows in by_pair.values()
        ),
    }


def evaluate_label_task(
    model: nn.Module,
    tokenizer: Any,
    controller: InterventionController,
    layer: int,
    seed: int,
    episodes: int,
    orbit: int,
    rho: float,
    family: str,
    carrier_mode: str,
    control: str,
    batch_size: int,
    record_trials: bool,
    carrier_split: str | None = None,
    direction_mode: str = "full",
    subspace_seed: int = 0,
) -> dict[str, Any]:
    model.eval()
    device = next(model.parameters()).device
    pending: list[tuple[Example, tuple[torch.Tensor, torch.Tensor]]] = []
    trials: list[dict[str, Any]] = []
    all_trials_for_summary: list[dict[str, Any]] = []

    def flush() -> None:
        if not pending:
            return
        examples = [item[0] for item in pending]
        encoded, plans, targets, ids = batch_examples(tokenizer, examples, device)
        controller.plan = plans
        with torch.inference_mode():
            logits = candidate_logits(model, encoded, ids)
        scales = list(controller.last_scales)
        controller.plan = None
        predictions = logits.argmax(dim=1)
        for index, (example, pair) in enumerate(pending):
            target = int(targets[index].item())
            prediction = int(predictions[index].item())
            wrong = 1 - target
            row = {
                **example.metadata,
                "prediction": "AB"[prediction],
                "correct": prediction == target,
                "logit_A": float(logits[index, 0].item()),
                "logit_B": float(logits[index, 1].item()),
                "margin": float((logits[index, target] - logits[index, wrong]).item()),
                "rho": example.rho,
                "realized_alpha": scales[index],
                "vector_family": family,
                "injection_layer": layer,
                "v1_hash": vector_fingerprint(pair[0]),
                "v2_hash": vector_fingerprint(pair[1]),
            }
            other_label = next(
                label for label in example.metadata["labels_by_vector"].values()
                if label != example.metadata["correct_label"]
            )
            row["predicted_label"] = example.metadata["correct_label"] if prediction == target else other_label
            all_trials_for_summary.append(row)
            if record_trials:
                trials.append(row)
        pending.clear()

    for episode_id in range(episodes):
        pair_seed = stable_seed(seed, f"eval-vector-{family}", episode_id)
        pair = sample_pair(
            int(model.config.hidden_size), pair_seed, family,
            direction_mode, subspace_seed,
        )
        transforms: list[tuple[bool, bool, bool]] = []
        for transform in range(8):
            transforms.append((bool(transform & 1), bool(transform & 2), bool(transform & 4)))
        transforms = transforms[:max(1, min(orbit, 8))]
        for mapping_swap, demo_reverse, option_reverse in transforms:
            for test_vector in (0, 1):
                example = label_example(
                    tokenizer, seed, episode_id, pair, test_vector, rho, "eval",
                    mapping_swap, demo_reverse, option_reverse, carrier_mode, control,
                    carrier_split,
                )
                pending.append((example, pair))
                if len(pending) >= batch_size:
                    flush()
    flush()
    summary = summarize_trials(all_trials_for_summary)
    summary.update({
        "seed": seed,
        "episodes": episodes,
        "orbit": orbit,
        "rho": rho,
        "vector_family": family,
        "carrier_mode": carrier_mode,
        "control": control,
        "layer": layer,
        "direction_mode": direction_mode,
        "subspace_seed": subspace_seed if direction_mode != "full" else None,
    })
    if record_trials:
        summary.update(primary_dependence_metrics(trials, seed))
        summary["trials"] = trials
    return summary


def create_model_and_tokenizer(args: argparse.Namespace) -> tuple[nn.Module, Any, list[str]]:
    tokenizer = AutoTokenizer.from_pretrained(args.model_id, use_fast=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    model = AutoModelForCausalLM.from_pretrained(
        args.model_id,
        dtype=torch.bfloat16,
        device_map={"": 0},
        low_cpu_mem_usage=True,
    )
    model.config.use_cache = False
    replaced = attach_lora(model, args.lora_start_layer, args.lora_rank, args.lora_alpha)
    return model, tokenizer, replaced


def train(args: argparse.Namespace) -> int:
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    model, tokenizer, replaced = create_model_and_tokenizer(args)
    layers = transformer_layers(model)
    train_layers = [int(value) for value in args.train_layers.split(",")]
    if any(layer < 0 or layer >= len(layers) for layer in train_layers):
        raise ValueError("training layer outside model")
    controllers = {layer: InterventionController() for layer in train_layers}
    handles = [layers[layer].register_forward_pre_hook(controllers[layer].hook) for layer in train_layers]
    parameters = [parameter for parameter in model.parameters() if parameter.requires_grad]
    trainable = sum(parameter.numel() for parameter in parameters)
    optimizer = torch.optim.AdamW(parameters, lr=args.learning_rate, weight_decay=args.weight_decay)

    def lr_lambda(step: int) -> float:
        if step < args.warmup_steps:
            return max(1e-3, step / max(1, args.warmup_steps))
        progress = (step - args.warmup_steps) / max(1, args.steps - args.warmup_steps)
        return 0.5 * (1 + math.cos(math.pi * min(1.0, progress)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    start_step = 0
    best_accuracy = -1.0
    checkpoint_path = output / "checkpoint.pt"
    if args.resume and checkpoint_path.exists():
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        load_adapter_state(model, checkpoint["adapter"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_step = int(checkpoint["step"])
        best_accuracy = float(checkpoint.get("best_accuracy", -1.0))
        torch.set_rng_state(checkpoint["torch_rng"])
        torch.cuda.set_rng_state_all(checkpoint["cuda_rng"])
        print(f"[{utc_now()}] resumed at step {start_step}", flush=True)

    metadata = {
        "status": "running",
        "started_at_utc": utc_now(),
        "host": platform.node(),
        "gpu": torch.cuda.get_device_name(0),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "model_id": args.model_id,
        "model_revision": getattr(model.config, "_commit_hash", None),
        "hidden_size": int(model.config.hidden_size),
        "num_layers": int(model.config.num_hidden_layers),
        "train_layers": train_layers,
        "lora_start_layer": args.lora_start_layer,
        "lora_rank": args.lora_rank,
        "lora_alpha": args.lora_alpha,
        "trainable_parameters": trainable,
        "target_modules": replaced,
        "seed": args.seed,
        "steps": args.steps,
        "localization_steps": args.localization_steps,
        "same_different_steps": args.same_different_steps,
        "validation_carrier_split": args.validation_carrier_split,
        "batch_size": args.batch_size,
        "rho_range": [args.rho_min, args.rho_max],
        "direction_mode": args.direction_mode,
        "subspace_seed": args.subspace_seed if args.direction_mode != "full" else None,
        "subspace_construction": (
            "deterministic signed, permuted block-Walsh-Hadamard basis; "
            "training and holdout supports partition its 5120 basis coordinates exactly"
            if args.direction_mode != "full" else None
        ),
        "candidate_tokens": {
            letters: candidate_tokens(tokenizer, letters)
            for letters in ("AB", "ABCD")
        },
    }
    atomic_json(output / "run-metadata.json", metadata)
    log_path = output / "training-log.jsonl"
    started = time.time()

    try:
        for step in range(start_step, args.steps):
            layer_rng = deterministic_random(args.seed, "training-layer", step)
            layer = train_layers[layer_rng.randrange(len(train_layers))]
            rho_rng = deterministic_random(args.seed, "training-rho", step)
            examples: list[Example] = []
            if step < args.localization_steps:
                rho = math.exp(rho_rng.uniform(
                    math.log(args.curriculum_rho_min), math.log(args.curriculum_rho_max)
                ))
                for row in range(args.batch_size):
                    episode = step * args.batch_size + row
                    examples.append(localization_example(
                        tokenizer, args.seed, episode, rho,
                        args.direction_mode, args.subspace_seed,
                    ))
                objective = "localization"
            elif step < args.localization_steps + args.same_different_steps:
                rho = math.exp(rho_rng.uniform(
                    math.log(args.curriculum_rho_min), math.log(args.curriculum_rho_max)
                ))
                for row in range(args.batch_size):
                    episode = step * args.batch_size + row
                    examples.append(same_different_example(
                        tokenizer, args.seed, episode, rho,
                        args.direction_mode, args.subspace_seed,
                    ))
                objective = "same-different"
            else:
                label_start = args.localization_steps + args.same_different_steps
                progress = (step - label_start) / max(1, args.steps - label_start - 1)
                if progress < 0.25:
                    low, high = args.curriculum_rho_min, args.curriculum_rho_max
                elif progress < 0.75:
                    interpolation = (progress - 0.25) / 0.5
                    low = math.exp(
                        (1 - interpolation) * math.log(args.curriculum_rho_min)
                        + interpolation * math.log(args.rho_min)
                    )
                    high = math.exp(
                        (1 - interpolation) * math.log(args.curriculum_rho_max)
                        + interpolation * math.log(args.rho_max)
                    )
                else:
                    low, high = args.rho_min, args.rho_max
                rho = (
                    DEFAULT_RHO
                    if progress >= 0.5 and rho_rng.random() < 0.25
                    else math.exp(rho_rng.uniform(math.log(low), math.log(high)))
                )
                if args.batch_size % 2:
                    raise ValueError("label-binding batch size must be even")
                base_count = args.batch_size // 2
                for base in range(base_count):
                    episode = step * base_count + base
                    pair = sample_pair(
                        int(model.config.hidden_size),
                        stable_seed(args.seed, "training-vector", episode),
                        "gaussian",
                        args.direction_mode,
                        args.subspace_seed,
                    )
                    transform = deterministic_random(args.seed, "training-transform", episode)
                    mapping_swap = bool(transform.randrange(2))
                    demo_reverse = bool(transform.randrange(2))
                    option_reverse = bool(transform.randrange(2))
                    carrier_mode = "different" if transform.random() < args.different_carrier_fraction else "same"
                    for test_vector in (0, 1):
                        examples.append(label_example(
                            tokenizer, args.seed, episode, pair, test_vector, rho, "train",
                            mapping_swap, demo_reverse, option_reverse, carrier_mode,
                        ))
                objective = "label-binding"

            model.train()
            encoded, plans, targets, ids = batch_examples(tokenizer, examples, next(model.parameters()).device)
            controllers[layer].plan = plans
            optimizer.zero_grad(set_to_none=True)
            logits = candidate_logits(model, encoded, ids)
            controllers[layer].plan = None
            loss = F.cross_entropy(logits, targets)
            loss.backward()
            grad_norm = float(torch.nn.utils.clip_grad_norm_(parameters, args.max_grad_norm).item())
            optimizer.step()
            scheduler.step()
            predictions = logits.argmax(dim=1)
            accuracy = float((predictions == targets).float().mean().item())
            row = {
                "step": step + 1,
                "objective": objective,
                "loss": float(loss.item()),
                "accuracy": accuracy,
                "grad_norm": grad_norm,
                "learning_rate": float(scheduler.get_last_lr()[0]),
                "layer": layer,
                "rho": rho,
                "tokens": int(encoded["attention_mask"].sum().item()),
                "elapsed_seconds": time.time() - started,
                "max_memory_gb": torch.cuda.max_memory_allocated() / 1e9,
            }
            with log_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(row, allow_nan=False) + "\n")
            if (step + 1) % args.log_every == 0 or step == start_step:
                print(
                    f"[{utc_now()}] step={step + 1}/{args.steps} objective={objective} "
                    f"loss={loss.item():.4f} acc={accuracy:.3f} grad={grad_norm:.3f} "
                    f"layer={layer} rho={rho:.4f} mem={row['max_memory_gb']:.1f}GB",
                    flush=True,
                )

            should_validate = (step + 1) % args.validation_every == 0 or step + 1 == args.steps
            if should_validate:
                validation = evaluate_label_task(
                    model, tokenizer, controllers[args.validation_layer], args.validation_layer,
                    args.seed + 90_000, args.validation_episodes, args.validation_orbit,
                    DEFAULT_RHO, "gaussian", "same", "primary", args.eval_batch_size, False,
                    args.validation_carrier_split,
                    args.direction_mode, args.subspace_seed,
                )
                controllers[train_layers[0]].plan = None
                validation["step"] = step + 1
                atomic_json(output / "latest-validation.json", validation)
                print(
                    f"[{utc_now()}] validation step={step + 1} "
                    f"accuracy={validation['accuracy']:.4f} margin={validation['mean_margin']:+.4f}",
                    flush=True,
                )
                if validation["accuracy"] > best_accuracy:
                    best_accuracy = validation["accuracy"]
                    atomic_torch_save(output / "best-adapter.pt", {
                        "adapter": adapter_state(model),
                        "step": step + 1,
                        "validation": validation,
                        "config": metadata,
                    })

            if (step + 1) % args.checkpoint_every == 0 or step + 1 == args.steps:
                atomic_torch_save(checkpoint_path, {
                    "adapter": adapter_state(model),
                    "optimizer": optimizer.state_dict(),
                    "scheduler": scheduler.state_dict(),
                    "step": step + 1,
                    "best_accuracy": best_accuracy,
                    "torch_rng": torch.get_rng_state(),
                    "cuda_rng": torch.cuda.get_rng_state_all(),
                    "config": metadata,
                })

        metadata["status"] = "completed"
        metadata["completed_at_utc"] = utc_now()
        metadata["duration_seconds"] = time.time() - started
        metadata["best_validation_accuracy"] = best_accuracy
        atomic_json(output / "run-metadata.json", metadata)
        atomic_torch_save(output / "final-adapter.pt", {
            "adapter": adapter_state(model),
            "step": args.steps,
            "config": metadata,
        })
        print(f"[{utc_now()}] training complete; best validation={best_accuracy:.4f}", flush=True)
        return 0
    finally:
        for controller in controllers.values():
            controller.plan = None
        for handle in handles:
            handle.remove()


def evaluate(args: argparse.Namespace) -> int:
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    model, tokenizer, replaced = create_model_and_tokenizer(args)
    adapter_file = None if args.adapter == "none" else Path(args.adapter)
    if adapter_file is None:
        saved: dict[str, Any] = {"adapter": {}, "step": 0, "config": {"condition": "base model"}}
    else:
        saved = torch.load(adapter_file, map_location="cpu", weights_only=False)
        load_adapter_state(model, saved["adapter"])
    layers = transformer_layers(model)
    eval_layers = [int(value) for value in args.eval_layers.split(",")]
    conditions: list[dict[str, Any]] = []
    trials: list[dict[str, Any]] = []
    handles: list[Any] = []
    try:
        for layer in eval_layers:
            controller = InterventionController()
            handle = layers[layer].register_forward_pre_hook(controller.hook)
            handles.append(handle)
            condition_specs: list[tuple[float, str, str, str]] = []
            if layer == DEFAULT_LAYER:
                condition_specs.extend([
                    (0.0, "gaussian", "same", "no-test"),
                    (0.02, "gaussian", "same", "primary"),
                    (0.05, "gaussian", "same", "primary"),
                    (0.1, "gaussian", "same", "primary"),
                    (0.2, "gaussian", "same", "primary"),
                    (0.1, "gaussian", "same", "no-test"),
                    (0.1, "gaussian", "same", "sign-flip"),
                    (0.1, "gaussian", "same", "orthogonal-test"),
                    (0.1, "rademacher", "same", "primary"),
                    (0.1, "sparse", "same", "primary"),
                    (0.1, "gaussian", "different", "primary"),
                ])
            else:
                condition_specs.append((0.1, "gaussian", "same", "primary"))
            for rho, family, carrier_mode, control in condition_specs:
                is_primary = (
                    layer == DEFAULT_LAYER and rho == 0.1 and family == "gaussian"
                    and carrier_mode == "same" and control == "primary"
                )
                result = evaluate_label_task(
                    model, tokenizer, controller, layer, args.seed,
                    args.primary_episodes if is_primary else args.secondary_episodes,
                    8 if is_primary else args.secondary_orbit,
                    rho, family, carrier_mode, control, args.eval_batch_size, is_primary,
                )
                if is_primary:
                    trials.extend(result.pop("trials"))
                    result["primary"] = True
                else:
                    result["primary"] = False
                conditions.append(result)
                print(
                    f"[{utc_now()}] eval layer={layer} rho={rho:.2f} family={family} "
                    f"carrier={carrier_mode} control={control} accuracy={result['accuracy']:.4f}",
                    flush=True,
                )
            handle.remove()
            handles.pop()
        artifact = {
            "schema_version": 1,
            "status": "completed",
            "completed_at_utc": utc_now(),
            "model_id": args.model_id,
            "adapter": str(adapter_file) if adapter_file is not None else None,
            "adapter_training_step": saved.get("step"),
            "adapter_config": saved.get("config", {}),
            "evaluation_seed": args.seed,
            "candidate_tokens": candidate_tokens(tokenizer, "AB"),
            "conditions": conditions,
            "primary_trials": trials,
            "implementation": {
                "dtype": "bfloat16",
                "vector_sampling": "fresh FP32 QR with randomized signs and column order",
                "normalization": "rho times per-row median normal residual norm at injected sites",
                "site": "resid_pre at carrier final period",
                "carrier_split": "evaluation uses a disjoint subject and predicate content-phrase pool",
                "lora_modules": replaced,
            },
        }
        atomic_json(output / "evaluation-results.json", artifact)
        return 0
    finally:
        for handle in handles:
            handle.remove()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("train", "eval"), default="train")
    parser.add_argument("--model-id", default=MODEL_ID)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--seed", type=int, default=20260820)
    parser.add_argument("--adapter")
    parser.add_argument("--steps", type=int, default=4000)
    parser.add_argument("--localization-steps", type=int, default=500)
    parser.add_argument("--same-different-steps", type=int, default=1000)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--eval-batch-size", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--max-grad-norm", type=float, default=1.0)
    parser.add_argument("--warmup-steps", type=int, default=200)
    parser.add_argument("--rho-min", type=float, default=0.02)
    parser.add_argument("--rho-max", type=float, default=0.2)
    parser.add_argument("--curriculum-rho-min", type=float, default=0.5)
    parser.add_argument("--curriculum-rho-max", type=float, default=2.0)
    parser.add_argument("--different-carrier-fraction", type=float, default=0.3)
    parser.add_argument(
        "--direction-mode",
        choices=("full", "subspace-train", "subspace-holdout"),
        default="full",
    )
    parser.add_argument("--subspace-seed", type=int, default=20260830)
    parser.add_argument("--train-layers", default="20")
    parser.add_argument("--eval-layers", default="16,20,24")
    parser.add_argument("--lora-start-layer", type=int, default=20)
    parser.add_argument("--lora-rank", type=int, default=16)
    parser.add_argument("--lora-alpha", type=float, default=32.0)
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument("--validation-every", type=int, default=250)
    parser.add_argument("--validation-episodes", type=int, default=32)
    parser.add_argument("--validation-orbit", type=int, default=2)
    parser.add_argument("--validation-layer", type=int, default=20)
    parser.add_argument(
        "--validation-carrier-split",
        choices=("train", "eval", "eval-train-pool"),
        default="eval-train-pool",
    )
    parser.add_argument("--checkpoint-every", type=int, default=250)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--primary-episodes", type=int, default=256)
    parser.add_argument("--secondary-episodes", type=int, default=128)
    parser.add_argument("--secondary-orbit", type=int, default=2)
    args = parser.parse_args()
    if args.mode == "eval" and not args.adapter:
        parser.error("--adapter is required in eval mode")
    if args.mode == "train" and args.direction_mode == "subspace-holdout":
        parser.error("training on the reserved holdout span is disallowed")
    train_layers = [int(value) for value in args.train_layers.split(",")]
    if args.mode == "train" and args.validation_layer not in train_layers:
        parser.error("--validation-layer must be included in --train-layers")
    return args


def main() -> int:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed & 0xFFFF_FFFF)
    random.seed(args.seed)
    torch.backends.cuda.matmul.allow_tf32 = True
    return train(args) if args.mode == "train" else evaluate(args)


if __name__ == "__main__":
    raise SystemExit(main())
