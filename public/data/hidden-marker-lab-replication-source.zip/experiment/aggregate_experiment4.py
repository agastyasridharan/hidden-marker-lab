#!/usr/bin/env python3
"""Aggregate Experiment 4 OOD and mechanistic artifacts for the dashboard."""

from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "experiment" / "results" / "experiment4"
PUBLIC = ROOT / "public" / "data"
FIXED_SEEDS = [20260820, 20260821, 20260822]
SUBSPACE_SEEDS = [20260830, 20260831, 20260832]


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def condition_map(artifact: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {row["id"]: row for row in artifact["conditions"]}


def episode_bootstrap(trials_by_model: list[list[dict[str, Any]]], seed: int) -> list[float]:
    by_model = []
    for trials in trials_by_model:
        grouped: dict[int, list[float]] = defaultdict(list)
        for row in trials:
            grouped[int(row["episode_id"])].append(float(row["correct"]))
        by_model.append({episode: statistics.fmean(values) for episode, values in grouped.items()})
    episodes = sorted(set.intersection(*(set(rows) for rows in by_model)))
    scores = np.array([statistics.fmean(rows[episode] for rows in by_model) for episode in episodes])
    rng = np.random.default_rng(seed)
    bootstrap = np.empty(10_000)
    for index in range(bootstrap.size):
        selected = rng.integers(0, scores.size, size=scores.size)
        bootstrap[index] = scores[selected].mean()
    return [float(np.quantile(bootstrap, .025)), float(np.quantile(bootstrap, .975))]


def compact_trial(row: dict[str, Any], model: str) -> dict[str, Any]:
    keys = [
        "condition", "episode_id", "test_vector", "correct_option", "correct_label",
        "labels_by_vector", "mapping_swap", "demo_reverse", "option_reverse",
        "carrier_mode", "sentences", "sentence", "prompt_variant", "site_mode",
        "prediction", "predicted_label", "correct", "logit_A", "logit_B", "margin",
        "rho", "realized_alpha", "vector_family", "pair_cosine", "direction_mode",
        "injection_layer", "v1_hash", "v2_hash",
    ]
    return {"model_condition": model, **{key: row[key] for key in keys if key in row}}


def find_head(rows: Iterable[dict[str, Any]], layer: int, head: int) -> dict[str, Any]:
    return next(row for row in rows if row.get("layer") == layer and row.get("head") == head)


def main(results: Path = RESULTS, public: Path = PUBLIC) -> None:
    base = read(results / "ood" / "base" / "ood-evaluation.json")
    fixed = [read(results / "ood" / f"seed-{seed}" / "ood-evaluation.json") for seed in FIXED_SEEDS]
    subspace = [read(results / "subspace" / f"seed-{seed}" / "ood-evaluation.json") for seed in SUBSPACE_SEEDS]
    base_conditions = condition_map(base)
    fixed_conditions = [condition_map(artifact) for artifact in fixed]

    condition_rows = []
    for condition_id in base_conditions:
        per_seed = [rows[condition_id] for rows in fixed_conditions]
        trials_by_seed = [
            [row for row in artifact["trials"] if row["condition"] == condition_id]
            for artifact in fixed
        ]
        condition_rows.append({
            "id": condition_id,
            "n_trials_per_seed": per_seed[0]["n_trials"],
            "base_accuracy": base_conditions[condition_id]["accuracy"],
            "mean_accuracy": statistics.fmean(row["accuracy"] for row in per_seed),
            "min_accuracy": min(row["accuracy"] for row in per_seed),
            "max_accuracy": max(row["accuracy"] for row in per_seed),
            "mean_margin": statistics.fmean(row["mean_margin"] for row in per_seed),
            "episode_cluster_ci_95": episode_bootstrap(trials_by_seed, 20261000 + len(condition_rows)),
            "per_seed": [
                {
                    "seed": seed,
                    "accuracy": row["accuracy"],
                    "mean_margin": row["mean_margin"],
                    "cluster_ci_95": row["cluster_bootstrap_ci_95"],
                }
                for seed, row in zip(FIXED_SEEDS, per_seed)
            ],
            "specification": {
                key: per_seed[0].get(key)
                for key in ("layer", "vector_family", "pair_cosine", "direction_mode", "prompt", "carrier", "site")
                if per_seed[0].get(key) is not None
            },
        })

    morph = []
    for angle in range(0, 91, 15):
        rows = [next(row for row in artifact["morph_summary"] if row["angle_degrees"] == angle) for artifact in fixed]
        morph.append({
            "angle_degrees": angle,
            "n_trials_per_seed": rows[0]["n_trials"],
            "mean_label_v2_minus_v1_logit": statistics.fmean(row["mean_label_v2_minus_v1_logit"] for row in rows),
            "mean_fraction_preferring_v2": statistics.fmean(row["fraction_preferring_v2"] for row in rows),
            "per_seed": [
                {
                    "seed": seed,
                    "mean_logit_contrast": row["mean_label_v2_minus_v1_logit"],
                    "fraction_preferring_v2": row["fraction_preferring_v2"],
                }
                for seed, row in zip(FIXED_SEEDS, rows)
            ],
        })

    subspace_rows = []
    for seed, artifact in zip(SUBSPACE_SEEDS, subspace):
        conditions = condition_map(artifact)
        training = read(results / "subspace" / f"seed-{seed}" / "run-metadata.json")
        train_row = conditions["dense_train_half"]
        holdout_row = conditions["dense_holdout_half"]
        subspace_rows.append({
            "seed": seed,
            "train_span": train_row,
            "holdout_span": holdout_row,
            "holdout_gap": train_row["accuracy"] - holdout_row["accuracy"],
            "training": {
                key: training[key]
                for key in (
                    "steps", "trainable_parameters", "best_validation_accuracy", "duration_seconds",
                    "gpu", "direction_mode", "subspace_seed", "subspace_construction",
                )
            },
        })

    screen_base = read(results / "mechanistic" / "screen-base" / "screen.json")
    screen_no_test = read(results / "mechanistic" / "screen-no-test-seed-20260820" / "screen.json")
    screens = [read(results / "mechanistic" / f"screen-seed-{seed}" / "screen.json") for seed in FIXED_SEEDS]
    mean_ablations = [read(results / "mechanistic" / f"mean-seed-{seed}" / "causal-mean.json") for seed in FIXED_SEEDS]
    patches = [read(results / "mechanistic" / f"patch-seed-{seed}" / "patch.json") for seed in FIXED_SEEDS]
    matcher_group = read(results / "mechanistic" / "group-matcher-seed-20260820" / "causal-mean.json")
    control_group = read(results / "mechanistic" / "group-control-seed-20260820" / "causal-mean.json")
    patch_base = read(results / "mechanistic" / "patch-base" / "patch.json")
    patch_control = read(results / "mechanistic" / "patch-control-seed-20260820" / "patch.json")

    head_summaries = []
    for layer, head, role in [(22, 17, "marker matcher"), (20, 29, "early marker processor"), (23, 36, "answer router")]:
        ablation_rows = [find_head(artifact["candidate_effects"], layer, head) for artifact in mean_ablations]
        patch_rows = []
        for artifact in patches:
            try:
                patch_rows.append(find_head(artifact["effects"], layer, head))
            except StopIteration:
                pass
        screen_rows = [find_head(artifact["head_scores"], layer, head) for artifact in screens]
        weight_rows = [find_head(artifact["weight_diagnostics"], layer, head) for artifact in screens]
        head_summaries.append({
            "layer": layer,
            "head": head,
            "role_hypothesis": role,
            "attention": {
                "mean_match_probability_contrast": statistics.fmean(row["match_probability_contrast"] for row in screen_rows),
                "per_seed": [row["match_probability_contrast"] for row in screen_rows],
            },
            "mean_ablation": {
                "mean_accuracy_drop": statistics.fmean(row["accuracy_drop"] for row in ablation_rows),
                "mean_margin_drop": statistics.fmean(row["mean_correct_margin_drop"] for row in ablation_rows),
                "per_seed_accuracy_drop": [row["accuracy_drop"] for row in ablation_rows],
                "per_seed_margin_drop": [row["mean_correct_margin_drop"] for row in ablation_rows],
                "per_seed_general_lm_nll_change": [row["general_lm_nll_increase"] for row in ablation_rows],
            },
            "counterfactual_patch": None if not patch_rows else {
                "mean_margin_reduction": statistics.fmean(row["mean_target_margin_reduction"] for row in patch_rows),
                "mean_answer_flip_fraction": statistics.fmean(row["fraction_target_answer_flipped"] for row in patch_rows),
                "per_seed_margin_reduction": [row["mean_target_margin_reduction"] for row in patch_rows],
                "per_seed_answer_flip_fraction": [row["fraction_target_answer_flipped"] for row in patch_rows],
            },
            "weight_diagnostics": {
                "mean_q_delta_relative_norm": statistics.fmean(row["q_delta_relative_norm"] for row in weight_rows),
                "mean_delta_qk_rowspace_alignment": statistics.fmean(row["delta_qk_rowspace_alignment"] for row in weight_rows),
            },
        })

    matcher_screen = find_head(screens[0]["head_scores"], 22, 17)
    matcher_no_test = find_head(screen_no_test["head_scores"], 22, 17)
    matcher_base = find_head(screen_base["head_scores"], 22, 17)
    matcher_group_row = matcher_group["candidate_effects"][0]
    control_group_row = control_group["candidate_effects"][0]
    base_patch_row = find_head(patch_base["effects"], 22, 17)
    control_patch_row = find_head(patch_control["effects"], 22, 8)

    aggregate = {
        "schema_version": 1,
        "status": "completed",
        "model_id": fixed[0]["model_id"],
        "model_revision": fixed[0]["model_revision"],
        "protocol_frozen_before_results": True,
        "evaluation_seed": fixed[0]["evaluation_seed"],
        "fixed_adapter_conditions": condition_rows,
        "morph": morph,
        "subspace": {
            "basis": "fixed signed, permuted block-Walsh-Hadamard orthonormal basis",
            "dimension": 5120,
            "train_dimension": 2560,
            "holdout_dimension": 2560,
            "dot_product_numerical_check_max": 1.862645149230957e-9,
            "success_gate": "each holdout accuracy >75% and mean holdout gap <=10 percentage points",
            "passed": all(row["holdout_span"]["accuracy"] > .75 for row in subspace_rows)
                and statistics.fmean(row["holdout_gap"] for row in subspace_rows) <= .10,
            "mean_train_accuracy": statistics.fmean(row["train_span"]["accuracy"] for row in subspace_rows),
            "mean_holdout_accuracy": statistics.fmean(row["holdout_span"]["accuracy"] for row in subspace_rows),
            "mean_holdout_gap": statistics.fmean(row["holdout_gap"] for row in subspace_rows),
            "runs": subspace_rows,
        },
        "mechanistic": {
            "verdict": (
                "Block 22 head 17 is a reliable causal marker-matching component within a redundant circuit. "
                "The evidence does not justify the broader label 'general introspection head'."
            ),
            "discovery_trials_per_model": screens[0]["n_trials"],
            "confirmation_trials_per_model": mean_ablations[0]["n_trials"],
            "head_summaries": head_summaries,
            "head_22_17_specificity": {
                "trained_primary_match_contrast": matcher_screen["match_probability_contrast"],
                "trained_no_test_match_contrast": matcher_no_test["match_probability_contrast"],
                "base_primary_match_contrast": matcher_base["match_probability_contrast"],
                "base_counterfactual_patch_margin_reduction": base_patch_row["mean_target_margin_reduction"],
                "trained_control_head_22_8_patch_margin_reduction": control_patch_row["mean_target_margin_reduction"],
            },
            "matcher_group": {
                "members": matcher_group_row["group"],
                "accuracy_drop": matcher_group_row["accuracy_drop"],
                "margin_drop": matcher_group_row["mean_correct_margin_drop"],
                "general_lm_nll_change": matcher_group_row["general_lm_nll_increase"],
            },
            "matched_control_group": {
                "members": control_group_row["group"],
                "accuracy_drop": control_group_row["accuracy_drop"],
                "margin_drop": control_group_row["mean_correct_margin_drop"],
                "general_lm_nll_change": control_group_row["general_lm_nll_increase"],
            },
            "candidate_selection": {
                "discovery_adapter": 20260820,
                "rankings": [
                    "trained-minus-base marker-match probability contrast",
                    "trained-minus-base marker-match attention log-ratio",
                    "answer-to-test attention",
                    "adapter Q/O relative norm",
                ],
                "confirmation_adapters": [20260821, 20260822],
                "negative_controls": ["20.4", "22.8", "23.21", "24.10", "25.12"],
            },
            "interpretation_limit": (
                "The task rewards matching externally injected residual perturbations. A marker-matching circuit can "
                "therefore be real and causal without constituting a domain-general faculty for introspection."
            ),
        },
        "artifacts": {
            "ood_audit": "/data/experiment4-ood-audit.json",
            "subspace_audit": "/data/experiment4-subspace-audit.json",
            "morph_audit": "/data/experiment4-morph-audit.json",
            "notebook": "/data/introspection-head-analysis.ipynb",
            "protocol": "/data/experiment4-protocol.md",
        },
    }

    ood_audit = {
        "schema_version": 1,
        "description": "Every categorical frozen-adapter OOD trial; base trials are a separate download.",
        "trial_count": sum(len(artifact["trials"]) for artifact in fixed),
        "trials": [
            compact_trial(row, artifact["model_condition"])
            for artifact in fixed for row in artifact["trials"]
        ],
    }
    base_audit = {
        "schema_version": 1,
        "description": "Every categorical base-model OOD trial.",
        "trial_count": len(base["trials"]),
        "trials": [compact_trial(row, "base") for row in base["trials"]],
    }
    subspace_trials = [
        compact_trial(row, artifact["model_condition"])
        for artifact in subspace for row in artifact["trials"]
    ]
    subspace_chunk_paths = [
        f"/data/experiment4-subspace-audit-seed-{seed}.json"
        for seed in SUBSPACE_SEEDS
    ]
    subspace_audit = {
        "schema_version": 1,
        "description": "Every in-span and orthogonal-holdout trial for the three span-restricted adapters.",
        "trial_count": len(subspace_trials),
        "chunks": subspace_chunk_paths,
    }
    morph_audit = {
        "schema_version": 1,
        "description": "Every angular-morph diagnostic trial; intermediate angles have no categorical ground truth.",
        "trial_count": sum(len(artifact["morph_trials"]) for artifact in fixed),
        "trials": [
            {"model_condition": artifact["model_condition"], **row}
            for artifact in fixed for row in artifact["morph_trials"]
        ],
    }
    write(public / "experiment4-results.json", aggregate)
    write(public / "experiment4-ood-audit.json", ood_audit)
    write(public / "experiment4-base-audit.json", base_audit)
    write(public / "experiment4-subspace-audit.json", subspace_audit)
    for seed, chunk_path in zip(SUBSPACE_SEEDS, subspace_chunk_paths):
        chunk_trials = [row for row in subspace_trials if row["model_condition"] == f"subspace-seed-{seed}"]
        write(public / Path(chunk_path).name, {
            "schema_version": 1,
            "description": f"Disjoint-span trials for adapter seed {seed}.",
            "seed": seed,
            "trial_count": len(chunk_trials),
            "trials": chunk_trials,
        })
    write(results / "complete-subspace-audit.json", {
        **subspace_audit,
        "chunks": subspace_chunk_paths,
        "trials": subspace_trials,
    })
    write(public / "experiment4-morph-audit.json", morph_audit)
    write(results / "aggregate-results.json", aggregate)
    print(json.dumps({
        "conditions": len(condition_rows),
        "ood_trials": ood_audit["trial_count"],
        "subspace_trials": subspace_audit["trial_count"],
        "morph_trials": morph_audit["trial_count"],
        "subspace_holdout_mean": aggregate["subspace"]["mean_holdout_accuracy"],
        "matcher_patch_margin": head_summaries[0]["counterfactual_patch"]["mean_margin_reduction"],
    }, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=RESULTS)
    parser.add_argument("--public", type=Path, default=PUBLIC)
    arguments = parser.parse_args()
    main(arguments.results, arguments.public)
